
import os
import asyncio
import threading
from datetime import datetime

import discord
from discord import Intents, app_commands
from discord.ext import commands

from profile_style import ProfileStyleService

import database
from database import (
    set_manually_stopped,
    get_account_by_requester,
    get_accounts_for_resume,
    remove_account,
    remove_account_by_requester,
    get_setting,
    set_setting,
)
from worker import (
    start_worker,
    stop_worker,
    get_worker,
    get_all_workers,
    is_completable,
    is_completed,
    WorkerAPI,
    fetch_latest_build_number,
)

BOT_TOKEN = os.environ.get("DISCORD_BOT_TOKEN", "").strip()

def _parse_guild_id(raw: str, fallback: int) -> int:
    import re
    raw = raw.strip()
    m = re.search(r'\d{17,20}', raw)
    if m:
        return int(m.group())
    return fallback

GUILD_ID = _parse_guild_id(os.environ.get("DISCORD_GUILD_ID", ""), 1424613516400394252)
OWNER_ID = _parse_guild_id(os.environ.get("OWNER_ID", ""), 0)
ALLOWED_GUILD = discord.Object(id=GUILD_ID)

BLUE  = 0x00BFFF
UI_TITLE = "Your Style"
HYPESQUAD_TITLE = "Your Style"
UI_FOOTER = "Your Style"



_QUEST_GIF   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "quest.gif")
_HYPESQUAD_BANNER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hypesquad_banner.webp")

intents = Intents.default()
intents.message_content = True
intents.members = True
intents.reactions = True
bot = commands.Bot(command_prefix=".", intents=intents, help_command=None)

# Display Name Style: chỉ áp dụng 1 lần mỗi process để tránh spam/rate-limit.
_name_effect_done = False


# ── Quest log channel 

def _quest_log_setting_key(guild_id: int | None = None) -> str:
    return f"quest_log_channel_id_{guild_id or GUILD_ID}"


def _get_quest_log_channel_id(guild_id: int | None = None) -> int | None:
    raw = get_setting(_quest_log_setting_key(guild_id))
    if raw is None:
        return None
    try:
        return int(str(raw).strip())
    except (TypeError, ValueError):
        return None


async def _get_quest_log_channel(guild_id: int | None = None):
    channel_id = _get_quest_log_channel_id(guild_id)
    if not channel_id:
        return None
    channel = bot.get_channel(channel_id)
    if channel is None:
        try:
            channel = await bot.fetch_channel(channel_id)
        except Exception:
            return None
    return channel


# ── Owner / bot admin access 

def _clone_admin_setting_key(guild_id: int | None = None) -> str:
    return f"clone_admin_ids_{guild_id or GUILD_ID}"


def _get_clone_admin_ids(guild_id: int | None = None) -> set[int]:
    raw = get_setting(_clone_admin_setting_key(guild_id)) or ""
    import re as _re
    return {int(x) for x in _re.findall(r"\d{17,20}", str(raw))}


def _save_clone_admin_ids(ids: set[int], guild_id: int | None = None) -> None:
    value = ",".join(str(x) for x in sorted(ids))
    set_setting(_clone_admin_setting_key(guild_id), value)


def _is_root_owner(user: discord.abc.User) -> bool:
    return bool(OWNER_ID and getattr(user, "id", 0) == OWNER_ID)


def _is_bot_admin(user: discord.abc.User, guild_id: int | None = None) -> bool:
    uid = getattr(user, "id", 0)
    if not uid:
        return False
    if OWNER_ID and uid == OWNER_ID:
        return True
    return uid in _get_clone_admin_ids(guild_id)



# ── Helpers 


async def _safe_respond(interaction: discord.Interaction, **kwargs):
    try:
        if interaction.response.is_done():
            await interaction.followup.send(**kwargs)
        else:
            await interaction.response.send_message(**kwargs)
    except discord.errors.HTTPException as e:
        if e.code == 40060:
            pass
        else:
            raise


# ── Quest panel embed 

def _build_quest_panel(username: str, user: discord.User | discord.Member, running: bool) -> discord.Embed:
    embed = discord.Embed(title=UI_TITLE, color=BLUE)
    embed.add_field(
        name="Auto Quest",
        value="Press Stat to view live progress",
        inline=True,
    )
    if user.avatar:
        embed.set_thumbnail(url=user.avatar.url)
    embed.add_field(name="\u200b", value="\u200b", inline=False)
    if running:
        embed.add_field(
            name="<a:_carregando_3_:1531535302118735954> **session running**",
            value="Press Stop to stop the session",
            inline=False,
        )
    else:
        embed.add_field(
            name="**Token ready** — press Start",
            value="Press Start to begin",
            inline=False,
        )
    embed.add_field(
        name="To update your token, press Change Token",
        value="Your token is stored securely",
        inline=False,
    )
    embed.set_footer(text=UI_FOOTER)
    return embed


# ── Token Modal 

class TokenModal(discord.ui.Modal):
    def __init__(self, mode: str = "add"):
        super().__init__(title=UI_TITLE)
        self.mode = mode
        self.token_input = discord.ui.TextInput(
            label="Discord Token",
            style=discord.TextStyle.paragraph,
            required=True,
            min_length=50,
            max_length=200,
        )
        self.add_item(self.token_input)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        token = self.token_input.value.strip()
        requester_id = str(interaction.user.id)

        account = database.add_account(token, requester_id=requester_id)
        if not account:
            await interaction.followup.send(
                "<:Screamgers:1530550207547183268> Invalid token. Please try another one.",
                ephemeral=True,
            )
            return

        username = account.get("username") or "User"
        user_id = account.get("user_id")

        if self.mode == "change":
            stop_worker(user_id)

        set_manually_stopped(user_id, False)
        embed = _build_quest_panel(username, interaction.user, running=False)
        view = QuestView(requester_id, user_id, username, token)
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)


# ── Quest View (Start button)

class QuestView(discord.ui.View):
    def __init__(self, requester_id: str, user_id: str, username: str, token: str):
        super().__init__(timeout=None)
        self.requester_id = requester_id
        self.user_id = user_id
        self.username = username
        self.token = token

    @discord.ui.button(label="Change Token", style=discord.ButtonStyle.secondary, emoji=discord.PartialEmoji.from_str("<:gwhitearrow:1534398940890271965>"), row=0)
    async def change_token(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.requester_id:
            await interaction.response.send_message("<:Screamgers:1530550207547183268> This panel does not belong to you.", ephemeral=True)
            return
        await interaction.response.send_modal(TokenModal(mode="change"))

    @discord.ui.button(label=" Start", style=discord.ButtonStyle.primary, emoji=discord.PartialEmoji.from_str("<a:BOOST:1531253087757664399>"), row=0)
    async def start_session(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.requester_id:
            await interaction.response.send_message("<:Screamgers:1530550207547183268> This account does not belong to you.", ephemeral=True)
            return

        # Quest DB là nguồn token duy nhất dùng chung for Quest + HypeSquad.
        # Refresh ngay lúc bấm Start để cả panel cũ cũng dùng token mới nhất.
        latest_account = get_account_by_requester(self.requester_id)
        if latest_account and latest_account.get("token"):
            self.token = latest_account["token"]
            self.user_id = latest_account.get("user_id") or self.user_id
            self.username = latest_account.get("username") or self.username

        if get_worker(self.user_id):
            await interaction.response.send_message(
                f"<a:AngryNOPGERS:1529018636356944038> `{self.username}` is already running. Press Stop before starting again.",
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True)

        def _fetch_actionable():
            try:
                build = fetch_latest_build_number()
                api = WorkerAPI(self.token, build)
                r = api.get("/quests/@me")
                api.close()
                if r.status_code == 200:
                    data = r.json()
                    qs = data.get("quests", []) if isinstance(data, dict) else data
                    return [q for q in qs if is_completable(q) and not is_completed(q)]
                if r.status_code in (401, 403):
                    return "DEAD_TOKEN"
                return None
            except Exception:
                return None

        loop = asyncio.get_event_loop()
        actionable = await loop.run_in_executor(None, _fetch_actionable)

        if actionable == "DEAD_TOKEN":
            embed = discord.Embed(
                title=UI_TITLE,
                description=(
                    "<:Screamgers:1530550207547183268> Your token has expired.\n\n"
                    "Press **Change Token** above to enter a new token."
                ),
                color=0xFF5555,
            )
            embed.set_footer(text=UI_FOOTER)
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        if actionable is not None and len(actionable) == 0:
            embed = discord.Embed(
                title=UI_TITLE,
                description=(
                    "<a:Verify:1537782070305362022> All Discord Quests have already been completed."
                ),
                color=0x57F287,
            )
            embed.set_footer(text=UI_FOOTER)
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        set_manually_stopped(self.user_id, False)
        avatar_url = str(interaction.user.avatar.url) if interaction.user.avatar else None
        rid = str(interaction.user.id)

        # Quest log dùng kênh riêng do /setlog hoặc .stl cấu hình.
        log_channel_id = _get_quest_log_channel_id(interaction.guild_id)
        status_msg = None
        if log_channel_id:
            try:
                ch = await _get_quest_log_channel(interaction.guild_id)
                if ch is not None:
                    init_embed = discord.Embed(
                        title=UI_TITLE,
                        description="<a:_carregando_3_:1531535302118735954> Connecting and loading the quest list...",
                        color=0x00BFFF,
                    )
                    init_embed.set_footer(text=UI_FOOTER)
                    if avatar_url:
                        init_embed.set_thumbnail(url=avatar_url)
                    status_msg = await ch.send(content=f"<@{rid}>", embed=init_embed)
            except Exception as e:
                print(f"[Bot] Failed to create quest log message: {e}", flush=True)
        else:
            print("[QuestLog] No log channel configured. Use .stl to set one.", flush=True)

        threading.Thread(
            target=start_worker,
            args=(
                self.token,
                self.user_id,
                self.username,
                5,
                True,
                bot,
                log_channel_id,
                rid,
                avatar_url,
            ),
            kwargs={
                "on_complete_callback": None,
                "pre_channel_msg": status_msg,
            },
            daemon=True,
        ).start()

        button.disabled = True
        button.label = "<a:Verify:1537782070305362022> Running..."
        embed = _build_quest_panel(self.username, interaction.user, running=True)
        await interaction.edit_original_response(embed=embed, view=self)


# ── Live Progress Embed 

def _build_live_progress_embed(workers: dict) -> discord.Embed:
    embed = discord.Embed(title=UI_TITLE, color=BLUE, timestamp=datetime.utcnow())
    embed.set_footer(text=UI_FOOTER)
    if not workers:
        embed.description = "<a:AngryNOPGERS:1529018636356944038> No accounts are currently running."
        return embed

    total_running = total_waiting = total_done = 0

    for uid, w in workers.items():
        quest_map = getattr(w, "_quest_map", {})
        if not quest_map:
            embed.add_field(name=f" {w.username}", value="<a:_carregando_3_:1531535302118735954> Starting...", inline=False)
            continue

        done = sum(1 for v in quest_map.values() if v["status"] == "done")
        total = len(quest_map)
        total_done += done

        lines = []
        for info in quest_map.values():
            st = info["status"]
            name = info["name"]
            sd = info.get("seconds_done", 0)
            sn = info.get("seconds_needed", 0)

            if st == "done":
                continue
            elif st == "running":
                total_running += 1
                if sn > 0:
                    pct = min(sd / sn, 1.0)
                    filled = int(pct * 10)
                    bar = "█" * filled + "░" * (10 - filled)
                    t_str = f"{int(sd // 60)}/{int(sn // 60)} min" if sn >= 60 else f"{int(sd)}/{int(sn)}s"
                    lines.append(f"<a:_carregando_3_:1531535302118735954> **{name}**\n`{bar}` {pct*100:.0f}% · {t_str}")
                else:
                    lines.append(f"<a:_carregando_3_:1531535302118735954> **{name}** · running...")
            else:
                total_waiting += 1
                lines.append(f"<a:_carregando_3_:1531535302118735954>  {name}")

        header = f"<a:Verify:1537782070305362022> {done}/{total} completed"
        if not lines:
            lines = ["<:Pikachugers:1531535307076407458> All quests completed!"]

        embed.add_field(name=f" {w.username}  —  {header}", value="\n".join(lines[:6]), inline=False)

    embed.set_footer(text=UI_FOOTER)
    return embed




# ── Shared Change Token modal (MenuQuest + HypeSquad) ─────────────────────────

class SharedChangeTokenModal(discord.ui.Modal):
    """Update the shared token used by MenuQuest and HypeSquad."""

    def __init__(self, source: str = "menuquest"):
        super().__init__(title=HYPESQUAD_TITLE if source == "hypesquad" else UI_TITLE)
        self.source = source
        self.token_input = discord.ui.TextInput(
            label="Discord Token",
            style=discord.TextStyle.paragraph,
            required=True,
            min_length=50,
            max_length=200,
        )
        self.add_item(self.token_input)

    async def on_submit(self, interaction: discord.Interaction):
        requester_id = str(interaction.user.id)
        old_account = get_account_by_requester(requester_id)
        old_user_id = old_account.get("user_id") if old_account else None

        await interaction.response.defer(ephemeral=True)
        token = self.token_input.value.strip()
        account = database.add_account(token, requester_id=requester_id)

        if not account:
            await interaction.followup.send(
                "<:Screamgers:1530550207547183268> Invalid token.",
                ephemeral=True,
            )
            return

        # Nếu đang farm bằng token cũ thì dừng session cũ để tránh worker tiếp tục
        # dùng credential trước khi thay đổi.
        if old_user_id:
            stop_worker(old_user_id)
        new_user_id = account.get("user_id")
        if new_user_id and new_user_id != old_user_id:
            stop_worker(new_user_id)
        if new_user_id:
            set_manually_stopped(new_user_id, False)

        username = account.get("username") or account.get("global_name") or "User"
        embed = discord.Embed(
            title=HYPESQUAD_TITLE if self.source == "hypesquad" else UI_TITLE,
            description=(
                f"Updated token for **{username}**.\n\n"
                "The new token is **shared by MenuQuest + HypeSquad**."
            ),
            color=0x57F287,
        )
        embed.set_footer(text=UI_FOOTER)
        await interaction.followup.send(embed=embed, ephemeral=True)


# ── HypeSquad panel (.hpsq) ──────────────────────────────────────────────────

HYPESQUAD_HOUSES = {
    "1": {"name": "Bravery",    "emoji": "<:brave:1537731034827853864>", "color": 0xE77035},
    "2": {"name": "Brilliance", "emoji": "<:brill:1537731036950302720>", "color": 0xF37B68},
    "3": {"name": "Balance",    "emoji": "<:balance:1537731039416426607>", "color": 0x45B384},
}


def _change_hypesquad(token: str, house_id: str) -> tuple[bool, str]:
    """Change HypeSquad while handling rate limits so interactions stay responsive."""
    import time as _time
    import random as _random
    import requests as _req

    headers = {
        "Authorization": token,
        "Content-Type": "application/json",
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "discord/1.0.9127 Chrome/127.0.6533.99 Electron/32.0.1 Safari/537.36"
        ),
    }

    # Discord có thể rate-limit endpoint HypeSquad sau nhiều lần đổi liên tiếp.
    # Retry ngắn ngay trong worker thread; nếu cooldown dài thì trả thông báo rõ ràng
    # thay vì để interaction fail khiến người dùng tưởng menu đã chết.
    for attempt in range(3):
        try:
            r = _req.post(
                "https://discord.com/api/v9/hypesquad/online",
                json={"house_id": int(house_id)},
                headers=headers,
                timeout=12,
            )

            if r.status_code in (200, 204):
                return True, "Success"
            if r.status_code == 401:
                return False, "The MenuQuest token is no longer valid. Change it in `.mq`."

            if r.status_code == 429:
                try:
                    data = r.json()
                    wait = float(data.get("retry_after", 5))
                except Exception:
                    wait = 5.0

                # Retry tự động nếu thời gian chờ ngắn. Thêm jitter nhỏ để tránh
                # nhiều cú click cùng quay lại đúng một thời điểm.
                if attempt < 2 and wait <= 15:
                    _time.sleep(max(0.5, wait) + _random.uniform(0.15, 0.45))
                    continue
                return False, (
                    f"Discord is rate-limiting HypeSquad changes. Wait **{wait:.1f}s** and try again. "
                    "The menu is still active; you do not need to send `.hpsq` again."
                )

            # Lỗi server tạm thời: thử lại tối đa 2 lần.
            if 500 <= r.status_code < 600 and attempt < 2:
                _time.sleep(1.0 + attempt)
                continue

            return False, f"Discord returned HTTP {r.status_code}"

        except (_req.Timeout, _req.ConnectionError) as exc:
            if attempt < 2:
                _time.sleep(1.0 + attempt)
                continue
            return False, f"Discord connection error: {exc}"
        except Exception as exc:
            return False, f"Connection error: {exc}"

    return False, "Unable to change HypeSquad right now. Please try again later."


class HypeSquadSharedTokenModal(discord.ui.Modal):
    """If no token exists, save it to the shared MenuQuest account database before applying the badge."""

    def __init__(self, house_id: str):
        super().__init__(title=HYPESQUAD_TITLE)
        self.house_id = house_id
        self.token_input = discord.ui.TextInput(
            label="Discord Token",
            style=discord.TextStyle.paragraph,
            required=True,
            min_length=50,
            max_length=200,
        )
        self.add_item(self.token_input)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        requester_id = str(interaction.user.id)
        token = self.token_input.value.strip()

        # Dùng cùng add_account/requester_id của MenuQuest, không tạo kho token HypeSquad riêng.
        account = database.add_account(token, requester_id=requester_id)
        if not account:
            await interaction.followup.send(
                "<:Screamgers:1530550207547183268> Invalid token.",
                ephemeral=True,
            )
            return

        # Đọc lại đúng token vừa lưu từ database Quest; HypeSquad không có kho token riêng.
        shared_account = get_account_by_requester(requester_id)
        shared_token = shared_account.get("token") if shared_account else None
        if not shared_token:
            await interaction.followup.send(
                "<:Screamgers:1530550207547183268> Unable to read the shared token from the Quest database.",
                ephemeral=True,
            )
            return

        house = HYPESQUAD_HOUSES[self.house_id]
        loop = asyncio.get_running_loop()
        ok, msg = await loop.run_in_executor(None, _change_hypesquad, shared_token, self.house_id)

        if ok:
            embed = discord.Embed(
                title=HYPESQUAD_TITLE,
                description=(
                    "<a:Verify:1537782070305362022> **Badge changed successfully!**\n\n"
                    "The token you entered is now **shared by MenuQuest + HypeSquad**.\n"
                    f"New house: **{house['name']}**"
                ),
                color=house["color"],
            )
        else:
            embed = discord.Embed(
                title=HYPESQUAD_TITLE,
                description=msg,
                color=0xFF0000,
            )
        embed.set_footer(text=UI_FOOTER)
        await interaction.followup.send(embed=embed, ephemeral=True)


class HypeSquadActionButton(discord.ui.Button):
    """Persistent buttons for the HypeSquad Components V2 menu."""

    def __init__(self, action: str):
        self.action = action
        config = {
            "1": {
                "label": "Bravery",
                "emoji": discord.PartialEmoji.from_str("<:brave:1537731034827853864>"),
                "style": discord.ButtonStyle.primary,
                "custom_id": "hypesquad_v2_bravery",
            },
            "2": {
                "label": "Brilliance",
                "emoji": discord.PartialEmoji.from_str("<:brill:1537731036950302720>"),
                "style": discord.ButtonStyle.danger,
                "custom_id": "hypesquad_v2_brilliance",
            },
            "3": {
                "label": "Balance",
                "emoji": discord.PartialEmoji.from_str("<:balance:1537731039416426607>"),
                "style": discord.ButtonStyle.success,
                "custom_id": "hypesquad_v2_balance",
            },
            "change": {
                "label": "Change Token",
                "emoji": discord.PartialEmoji.from_str("<:gwhitearrow:1534398940890271965>"),
                "style": discord.ButtonStyle.secondary,
                "custom_id": "hypesquad_v2_change_token",
            },
        }[action]
        super().__init__(
            label=config["label"],
            emoji=config["emoji"],
            style=config["style"],
            custom_id=config["custom_id"],
        )

    async def callback(self, interaction: discord.Interaction):
        if self.action == "change":
            await interaction.response.send_modal(SharedChangeTokenModal(source="hypesquad"))
            return
        await _apply_hypesquad(interaction, self.action)


_HYPESQUAD_USER_LOCKS: dict[str, asyncio.Lock] = {}


async def _apply_hypesquad(interaction: discord.Interaction, house_id: str):
    """Read the latest token from the Quest DB on every click and serialize requests per user to avoid bucket spam."""
    requester_id = str(interaction.user.id)
    account = get_account_by_requester(requester_id)

    if not account or not account.get("token"):
        await interaction.response.send_modal(HypeSquadSharedTokenModal(house_id))
        return

    # ACK ngay để Discord không báo Interaction Failed trong lúc API đang cooldown/retry.
    await interaction.response.defer(ephemeral=True, thinking=True)

    lock = _HYPESQUAD_USER_LOCKS.get(requester_id)
    if lock is None:
        lock = asyncio.Lock()
        _HYPESQUAD_USER_LOCKS[requester_id] = lock

    async with lock:
        # Đọc lại SAU khi lấy lock để luôn dùng token mới nhất nếu vừa Change Token.
        account = get_account_by_requester(requester_id)
        token = account.get("token") if account else None
        if not token:
            await interaction.followup.send(
                "<:Screamgers:1530550207547183268> No shared token found. Use **Change Token**.",
                ephemeral=True,
            )
            return

        house = HYPESQUAD_HOUSES[house_id]
        loop = asyncio.get_running_loop()
        ok, msg = await loop.run_in_executor(None, _change_hypesquad, token, house_id)

        if ok:
            embed = discord.Embed(
                title=HYPESQUAD_TITLE,
                description=(
                    "<a:Verify:1537782070305362022> **Badge changed successfully!**\n\n"
                    f"MenuQuest account: **{account.get('username') or account.get('user_id') or 'User'}**\n"
                    f"New house: **{house['name']}**"
                ),
                color=house["color"],
            )
        else:
            embed = discord.Embed(
                title=HYPESQUAD_TITLE,
                description=msg,
                color=0xFF0000,
            )

        embed.set_footer(text=UI_FOOTER)
        await interaction.followup.send(embed=embed, ephemeral=True)


class HypeSquadView(discord.ui.LayoutView):
    """Persistent Components V2: timeout=None with fixed custom_id so controls remain active."""

    def __init__(self):
        super().__init__(timeout=None)

        container = discord.ui.Container(accent_colour=BLUE)
        container.add_item(discord.ui.TextDisplay(
            f"## {HYPESQUAD_TITLE}\n"
            "Choose a **HypeSquad House** below.\n"
            "The token is **shared with MenuQuest**."
        ))

        if os.path.exists(_HYPESQUAD_BANNER):
            gallery = discord.ui.MediaGallery()
            gallery.add_item(
                media="attachment://hypesquad_banner.webp",
                description="HypeSquad",
            )
            container.add_item(gallery)

        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.ActionRow(
            HypeSquadActionButton("1"),
            HypeSquadActionButton("2"),
            HypeSquadActionButton("3"),
            HypeSquadActionButton("change"),
        ))
        container.add_item(discord.ui.TextDisplay(f"-# {UI_FOOTER}"))
        self.add_item(container)

    async def on_error(self, interaction: discord.Interaction, error: Exception, item) -> None:
        # Không để lỗi callback biến thành "This interaction failed" và làm menu trông như dead.
        print(f"[HypeSquad] Interaction error: {error}", flush=True)
        try:
            if interaction.response.is_done():
                await interaction.followup.send(
                    "<:Screamgers:1530550207547183268> A temporary error occurred. The menu is still active; try again in a few seconds.",
                    ephemeral=True,
                )
            else:
                await interaction.response.send_message(
                    "<:Screamgers:1530550207547183268> A temporary error occurred. The menu is still active; try again in a few seconds.",
                    ephemeral=True,
                )
        except Exception:
            pass


async def _send_hypesquad_panel(target_channel):
    """Send the HypeSquad panel using the same pattern as _send_menu_to_channel(.mq)."""
    if target_channel is None:
        return False, "no_channel"
    try:
        if os.path.exists(_HYPESQUAD_BANNER):
            banner = discord.File(_HYPESQUAD_BANNER, filename="hypesquad_banner.webp")
            await target_channel.send(view=HypeSquadView(), file=banner)
        else:
            await target_channel.send(view=HypeSquadView())
        return True, None
    except discord.Forbidden:
        return False, "403"
    except Exception as exc:
        print(f"[HypeSquad] Failed to send panel: {exc}", flush=True)
        return False, "other"


# ── /menu Buttons & Subviews 
class MenuActionButton(discord.ui.Button):
    def __init__(self, action: str):
        self.action = action

        config = {
            "quest": {
                "label": "Quest",
                "emoji": discord.PartialEmoji.from_str("<a:BOOST:1531253087757664399>"),
                "style": discord.ButtonStyle.success,
                "custom_id": "menuquest_quest",
            },
            "change": {
                "label": "Change Token",
                "emoji": discord.PartialEmoji.from_str("<:gwhitearrow:1534398940890271965>"),
                "style": discord.ButtonStyle.secondary,
                "custom_id": "menuquest_change_token",
            },
            "stat": {
                "label": "Stat",
                "emoji": discord.PartialEmoji.from_str("<:Discord_OrbsBook:1534185180078670036>"),
                "style": discord.ButtonStyle.primary,
                "custom_id": "menuquest_stat",
            },
            "stop": {
                "label": "Stop",
                "emoji": discord.PartialEmoji.from_str("<:gwhitearrow:1534398940890271965>"),
                "style": discord.ButtonStyle.danger,
                "custom_id": "menuquest_stop",
            },
        }[action]

        super().__init__(
            label=config["label"],
            emoji=config["emoji"],
            style=config["style"],
            custom_id=config["custom_id"],
        )

    async def callback(self, interaction: discord.Interaction):
        requester_id = str(interaction.user.id)
        member = interaction.user

        # QUEST 
        if self.action == "quest":
            existing = get_account_by_requester(requester_id)

            if not existing or not existing.get("token"):
                await interaction.response.send_modal(TokenModal(mode="add"))
                return

            await interaction.response.defer(ephemeral=True)

            username = existing.get("username") or "User"
            user_id = existing.get("user_id")
            running = bool(get_worker(user_id))
            embed = _build_quest_panel(username, interaction.user, running)
            view = QuestView(requester_id, user_id, username, existing["token"])
            await interaction.followup.send(embed=embed, view=view, ephemeral=True)
            return

        # CHANGE TOKEN
        if self.action == "change":
            await interaction.response.send_modal(SharedChangeTokenModal(source="menuquest"))
            return

        # STAT 
        if self.action == "stat":
            await interaction.response.defer(ephemeral=True)
            workers = get_all_workers()
            embed = _build_live_progress_embed(workers)
            await interaction.followup.send(embed=embed, ephemeral=True)
            return

        # STOP 
        if self.action == "stop":
            await interaction.response.defer(ephemeral=True)

            acc = get_account_by_requester(requester_id)
            target_uid = acc.get("user_id") if acc else requester_id
            workers = get_all_workers()
            filtered = {uid: w for uid, w in workers.items() if uid == target_uid}

            if not filtered:
                await interaction.followup.send(
                    "<a:AngryNOPGERS:1529018636356944038> Your account is not currently running quests.",
                    ephemeral=True,
                )
                return

            stopped = []
            for uid in list(filtered.keys()):
                w = workers.get(uid)
                if w:
                    stopped.append(w.username)
                    stop_worker(uid)
                    set_manually_stopped(uid, True)

            embed = discord.Embed(
                title=UI_TITLE,
                description=(
                    f"<a:Verify:1537782070305362022> Stopped: **{', '.join(stopped)}**\n"
                ),
                color=BLUE,
            )
            embed.set_footer(text=UI_FOOTER)

            try:
                ch = await _get_quest_log_channel(interaction.guild_id)
                if ch is not None:
                    await ch.send(content=f"{interaction.user.mention}", embed=embed)
                else:
                    await interaction.followup.send(embed=embed, ephemeral=True)
            except Exception:
                await interaction.followup.send(embed=embed, ephemeral=True)


class MenuView(discord.ui.LayoutView):
    """Components V2 MENUQUEST with Quest / Change Token / Stat / Stop."""

    def __init__(self):
        super().__init__(timeout=None)

        container = discord.ui.Container(accent_colour=BLUE)
        container.add_item(discord.ui.TextDisplay(
            "## Your Style\n"
            "Automatically complete supported Discord quests with simple controls."
        ))

        if os.path.exists(_QUEST_GIF):
            gallery = discord.ui.MediaGallery()
            gallery.add_item(
                media="attachment://quest.gif",
                description="Your Style",
            )
            container.add_item(gallery)

        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.ActionRow(
            MenuActionButton("quest"),
            MenuActionButton("change"),
            MenuActionButton("stat"),
            MenuActionButton("stop"),
        ))
        container.add_item(discord.ui.TextDisplay(f"-# {UI_FOOTER}"))
        self.add_item(container)


# ── Menu helpers 

async def _send_menu_to_channel(target_channel):

    if target_channel is None:
        return False, "no_channel"
    try:
        if os.path.exists(_QUEST_GIF):
            file = discord.File(_QUEST_GIF, filename="quest.gif")
            await target_channel.send(view=MenuView(), file=file)
        else:
            await target_channel.send(view=MenuView())
        return True, None
    except discord.Forbidden:
        return False, "403"
    except Exception as e:
        print(f"[Menu] Failed to send MENUQUEST: {e}", flush=True)
        return False, "other"

# ── Reset Token 

def _normalize_reset_user_id(raw: str) -> str | None:
    uid = (raw or "").strip().strip("<@!>")
    return uid if uid.isdigit() else None


async def _reset_token_for_user_id(raw_user_id: str) -> tuple[bool, str]:
    uid = _normalize_reset_user_id(raw_user_id)
    if not uid:
        return False, "<:Screamgers:1530550207547183268> Invalid User ID"

    # Lấy account trước khi xóa để biết worker Discord-account nào cần dừng.
    existing = await asyncio.to_thread(get_account_by_requester, uid)
    worker_uid = str(existing.get("user_id")) if existing and existing.get("user_id") else uid

    removed = await asyncio.to_thread(remove_account_by_requester, uid)
    if not removed:
        removed = await asyncio.to_thread(remove_account, uid)

    try:
        stop_worker(worker_uid)
    except Exception:
        pass

    if removed:
        return True, f"<a:Verify:1537782070305362022> Reset/deleted the token for user ID `{uid}`."
    return False, f"<a:AngryNOPGERS:1529018636356944038> No saved token found for user ID `{uid}`."


def _parse_reset_user_ids(raw: str) -> list[str]:
    """Parse multiple Discord User IDs from new lines, commas, or spaces."""
    import re

    ids = []
    seen = set()
    for uid in re.findall(r"\d{5,25}", raw or ""):
        if uid not in seen:
            seen.add(uid)
            ids.append(uid)
    return ids


async def _reset_many_user_ids(raw: str) -> tuple[list[str], int, int]:
    user_ids = _parse_reset_user_ids(raw)
    if not user_ids:
        return ["<:Screamgers:1530550207547183268> No valid User ID found."], 0, 0

    # Tránh một lần submit quá lớn làm nghẽn worker/database.
    user_ids = user_ids[:50]
    lines = []
    success = 0
    missing = 0

    for uid in user_ids:
        ok, message = await _reset_token_for_user_id(uid)
        lines.append(message)
        if ok:
            success += 1
        else:
            missing += 1

    return lines, success, missing


class ResetTokenModal(discord.ui.Modal, title=UI_TITLE):
    user_ids = discord.ui.TextInput(
        label="Discord User IDs",
        placeholder="One ID per line, or separate IDs with commas / spaces",
        style=discord.TextStyle.paragraph,
        required=True,
        max_length=4000,
    )

    async def on_submit(self, interaction: discord.Interaction):
        if not interaction.guild or not _is_bot_admin(interaction.user, interaction.guild.id if interaction.guild else None):
            await interaction.response.send_message(
                "<:Screamgers:1530550207547183268> Only the OWNER or an admin authorized by the OWNER can use this feature.",
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True)
        lines, success, missing = await _reset_many_user_ids(str(self.user_ids.value))

        header = f"<a:Verify:1537782070305362022> Reset: **{success}** • Not found/not reset: **{missing}**"
        body = "\n".join(lines)

        # Discord giới hạn message, nên cắt phần chi tiết nếu danh sách dài.
        if len(body) > 1800:
            body = body[:1800] + "\n… (results truncated)"

        await interaction.followup.send(
            f"{header}\n\n{body}",
            ephemeral=True,
        )


@bot.tree.command(name="resettoken", description="Open the token reset form for multiple Discord User IDs (OWNER/Admin only)")
async def resettoken_slash(interaction: discord.Interaction):
    if not interaction.guild or not _is_bot_admin(interaction.user, interaction.guild.id if interaction.guild else None):
        await interaction.response.send_message(
            "<:Screamgers:1530550207547183268> Only the OWNER or an admin authorized by the OWNER can use this command.",
            ephemeral=True,
        )
        return

    await interaction.response.send_modal(ResetTokenModal())


@bot.command(name="rstk")
async def resettoken_prefix(ctx: commands.Context, *, user_ids: str | None = None):
    if not isinstance(ctx.author, discord.Member) or not _is_bot_admin(ctx.author, ctx.guild.id if ctx.guild else None):
        await ctx.send("<:Screamgers:1530550207547183268> Only the OWNER or an admin authorized by the OWNER can use this command.")
        return

    if not user_ids:
        await ctx.send(
            f"<:Screamgers:1530550207547183268> Prefix commands cannot open a Modal directly. Use `/{'resettoken'}` to open the form, "
            f"or `{bot.command_prefix}rstk <id1> <id2> ...`"
        )
        return

    lines, success, missing = await _reset_many_user_ids(user_ids)
    body = "\n".join(lines)
    if len(body) > 1800:
        body = body[:1800] + "\n… (results truncated)"

    await ctx.send(
        f"<a:Verify:1537782070305362022> Reset: **{success}** • Not found/not reset: **{missing}**\n\n{body}"
    )


# ── Add clone admin commands 

@bot.tree.command(name="addclone", description="Grant bot admin access to a user (OWNER only)")
@app_commands.describe(user="User who will receive permission to use bot admin commands")
async def addclone_slash(interaction: discord.Interaction, user: discord.Member):
    if interaction.guild is None:
        await interaction.response.send_message("<:Screamgers:1530550207547183268> This command can only be used in a server.", ephemeral=True)
        return
    if not _is_root_owner(interaction.user):
        await interaction.response.send_message("<:Screamgers:1530550207547183268> Only OWNER_ID from `.env` can use `/addclone`.", ephemeral=True)
        return

    if user.id == OWNER_ID:
        await interaction.response.send_message("<a:AngryNOPGERS:1529018636356944038> The OWNER already has full access.", ephemeral=True)
        return

    admins = _get_clone_admin_ids(interaction.guild.id)
    if user.id in admins:
        await interaction.response.send_message(f"<a:AngryNOPGERS:1529018636356944038> {user.mention} already has bot admin access.", ephemeral=True)
        return

    admins.add(user.id)
    _save_clone_admin_ids(admins, interaction.guild.id)
    await interaction.response.send_message(
        f"<a:Verify:1537782070305362022> Added {user.mention} as a **bot admin**.\n"
        "Bot access has been granted.",
        ephemeral=True,
    )


@bot.command(name="adcl")
async def addclone_prefix(ctx: commands.Context, user_id: str | None = None):
    """.adcl <user_id> — OWNER grants bot admin access."""
    if ctx.guild is None:
        await ctx.send("<:Screamgers:1530550207547183268> This command can only be used in a server.")
        return
    if not _is_root_owner(ctx.author):
        await ctx.send("<:Screamgers:1530550207547183268> Only OWNER_ID from `.env` can use `.adcl`.")
        return
    if not user_id:
        await ctx.send("<:Screamgers:1530550207547183268> Usage: `.adcl <user_id>` or `.adcl @user`")
        return

    import re as _re
    match = _re.search(r"\d{17,20}", user_id)
    if not match:
        await ctx.send("<:Screamgers:1530550207547183268> Invalid User ID.")
        return

    uid = int(match.group())
    if uid == OWNER_ID:
        await ctx.send("<a:AngryNOPGERS:1529018636356944038> This ID is already the root OWNER.")
        return

    member = ctx.guild.get_member(uid)
    if member is None:
        try:
            member = await ctx.guild.fetch_member(uid)
        except Exception:
            member = None
    if member is None:
        await ctx.send("<:Screamgers:1530550207547183268> This user was not found in the current server.")
        return

    admins = _get_clone_admin_ids(ctx.guild.id)
    if uid in admins:
        await ctx.send(f"<a:AngryNOPGERS:1529018636356944038> {member.mention} already has bot admin access.")
        return

    admins.add(uid)
    _save_clone_admin_ids(admins, ctx.guild.id)
    await ctx.send(
        f"<a:Verify:1537782070305362022> Added {member.mention} as a **bot admin**. "
        "This user can now use `.mq`, `.stl`, `.rstk`, and the corresponding slash commands."
    )


@bot.command(name="rmvcl")
async def removeclone_prefix(ctx: commands.Context, user_id: str | None = None):
    """.rmvcl <user_id|@user> — OWNER removes bot admin access granted with .adcl."""
    if ctx.guild is None:
        await ctx.send("<:Screamgers:1530550207547183268> This command can only be used in a server.")
        return
    if not _is_root_owner(ctx.author):
        await ctx.send("<:Screamgers:1530550207547183268> Only OWNER_ID from `.env` can use `.rmvcl`.")
        return
    if not user_id:
        await ctx.send("<:Screamgers:1530550207547183268> Usage: `.rmvcl @user` or `.rmvcl <user_id>`")
        return

    import re as _re
    match = _re.search(r"\d{17,20}", user_id)
    if not match:
        await ctx.send("<:Screamgers:1530550207547183268> Invalid User ID.")
        return

    uid = int(match.group())
    if uid == OWNER_ID:
        await ctx.send("<a:AngryNOPGERS:1529018636356944038> The root OWNER cannot be removed with `.rmvcl`.")
        return

    admins = _get_clone_admin_ids(ctx.guild.id)
    if uid not in admins:
        member = ctx.guild.get_member(uid)
        target = member.mention if member else f"`{uid}`"
        await ctx.send(f"<a:AngryNOPGERS:1529018636356944038> {target} does not have clone admin access.")
        return

    admins.discard(uid)
    _save_clone_admin_ids(admins, ctx.guild.id)

    member = ctx.guild.get_member(uid)
    if member is None:
        try:
            member = await ctx.guild.fetch_member(uid)
        except Exception:
            member = None
    target = member.mention if member else f"`{uid}`"
    await ctx.send(
        f"<a:Verify:1537782070305362022> Removed {target} from **clone admin**. "
        "This user no longer has bot admin access granted by `.adcl`."
    )


# ── Quest log channel commands 

@bot.tree.command(name="setlog", description="Choose the channel for Quest logs (OWNER/Admin)")
@app_commands.describe(channel="Text channel that will receive Quest status and results")
async def setlog_slash(interaction: discord.Interaction, channel: discord.TextChannel):
    if not isinstance(interaction.user, discord.Member) or not _is_bot_admin(interaction.user, interaction.guild.id if interaction.guild else None):
        await interaction.response.send_message("<:Screamgers:1530550207547183268> Only the **OWNER or an admin authorized by the OWNER** can use this command.", ephemeral=True)
        return

    if interaction.guild is None or channel.guild.id != interaction.guild.id:
        await interaction.response.send_message("<:Screamgers:1530550207547183268> The log channel must belong to the current server.", ephemeral=True)
        return

    me = interaction.guild.me
    if me is not None:
        perms = channel.permissions_for(me)
        if not perms.send_messages:
            await interaction.response.send_message(
                f"<:Screamgers:1530550207547183268> The bot does not have **Send Messages** permission in {channel.mention}.",
                ephemeral=True,
            )
            return

    set_setting(_quest_log_setting_key(interaction.guild.id), str(channel.id))
    await interaction.response.send_message(
        f"<a:Verify:1537782070305362022> Set **Quest Log** to {channel.mention}.\n"
        "Quest status, progress, and results will now be sent here separately from MENUQUEST.",
        ephemeral=True,
    )


@bot.command(name="stl")
async def setlog_prefix(ctx: commands.Context, channel_id: str | None = None):
    """.stl <channel_id> — set the Quest log channel."""
    if not isinstance(ctx.author, discord.Member) or not _is_bot_admin(ctx.author, ctx.guild.id if ctx.guild else None):
        await ctx.send("<:Screamgers:1530550207547183268> Only the **OWNER or an admin authorized by the OWNER** can use this command.")
        return
    if ctx.guild is None:
        await ctx.send("<:Screamgers:1530550207547183268> This command can only be used in a server.")
        return
    if not channel_id:
        await ctx.send("<:Screamgers:1530550207547183268> Usage: `.stl <channel_id>` or `.stl #channel`")
        return

    import re as _re
    match = _re.search(r"\d{17,20}", channel_id)
    if not match:
        await ctx.send("<:Screamgers:1530550207547183268> Invalid Channel ID.")
        return

    cid = int(match.group())
    channel = ctx.guild.get_channel(cid)
    if channel is None:
        try:
            fetched = await bot.fetch_channel(cid)
            channel = fetched if getattr(fetched, "guild", None) and fetched.guild.id == ctx.guild.id else None
        except Exception:
            channel = None

    if not isinstance(channel, discord.TextChannel):
        await ctx.send("<:Screamgers:1530550207547183268> This ID is not a text channel in the current server.")
        return

    me = ctx.guild.me
    if me is not None and not channel.permissions_for(me).send_messages:
        await ctx.send(f"<:Screamgers:1530550207547183268> The bot does not have **Send Messages** permission in {channel.mention}.")
        return

    set_setting(_quest_log_setting_key(ctx.guild.id), str(channel.id))
    await ctx.send(f"<a:Verify:1537782070305362022> Quest Log → {channel.mention}")


# ── /menuquest slash command 

@bot.tree.command(name="menuquest", description="Open MENUQUEST (OWNER/Admin only)")
async def menuquest_slash(interaction: discord.Interaction):
    """Keep /menuquest and use .mq as a prefix alias for the same MENUQUEST."""
    member = interaction.user
    if not isinstance(member, discord.Member) or not _is_bot_admin(member, interaction.guild.id if interaction.guild else None):
        await interaction.response.send_message(
            "<:Screamgers:1530550207547183268> Only the **OWNER or an admin authorized by the OWNER** can use this command.",
            ephemeral=True,
        )
        return

    # Acknowledge interaction trước rồi gửi MENUQUEST public vào chính channel hiện tại.
    await interaction.response.defer(ephemeral=True)
    success, err_type = await _send_menu_to_channel(interaction.channel)

    if not success:
        if err_type == "403":
            await interaction.followup.send(
                "<:Screamgers:1530550207547183268> The bot cannot send MENUQUEST in this channel. "
                "It needs `Send Messages` and `Attach Files`.",
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                "<:Screamgers:1530550207547183268> Unable to send MENUQUEST in the current channel. Check the bot permissions.",
                ephemeral=True,
            )
        return

    await interaction.followup.send("<a:Verify:1537782070305362022> MENUQUEST sent.", ephemeral=True)


# ── .mq prefix command 

@bot.command(name="mq")
async def menuquest_prefix(ctx: commands.Context):
    """Open MENUQUEST with the .mq prefix (OWNER/Admin only)."""
    if not isinstance(ctx.author, discord.Member) or not _is_bot_admin(ctx.author, ctx.guild.id if ctx.guild else None):
        await ctx.send("<:Screamgers:1530550207547183268> Only the **OWNER or an admin authorized by the OWNER** can use this command.")
        return

    success, err_type = await _send_menu_to_channel(ctx.channel)

    if not success:
        if err_type == "403":
            await ctx.send(
                "<:Screamgers:1530550207547183268> The bot cannot send MENUQUEST in this channel. "
                "It needs `Send Messages` and `Attach Files`."
            )
        else:
            await ctx.send(
                "<:Screamgers:1530550207547183268> Unable to send MENUQUEST in the current channel. Check the bot permissions."
            )
        return

    try:
        await ctx.message.add_reaction("<a:Verify:1537782070305362022>")
    except Exception:
        pass


# ── .hpsq prefix command

@bot.command(name="hpsq")
async def hypesquad_prefix(ctx: commands.Context):
    """Open the persistent HypeSquad Components V2 menu using the same send flow as .mq."""
    success, err_type = await _send_hypesquad_panel(ctx.channel)
    if not success:
        if err_type == "403":
            await ctx.send(
                "<:Screamgers:1530550207547183268> The bot cannot send the HypeSquad menu in this channel. "
                "It needs `Send Messages` and `Attach Files`."
            )
        else:
            await ctx.send(
                "<:Screamgers:1530550207547183268> Unable to send the HypeSquad menu in the current channel."
            )
        return
    try:
        await ctx.message.add_reaction("<a:Verify:1537782070305362022>")
    except Exception:
        pass


# ── Error handler 

@bot.tree.error
async def on_tree_error(interaction: discord.Interaction, error: discord.app_commands.AppCommandError):
    original = getattr(error, "original", error)
    if isinstance(original, discord.errors.HTTPException) and original.code == 40060:
        return
    try:
        await _safe_respond(interaction, content="<:Screamgers:1530550207547183268> An error occurred.", ephemeral=True)
    except Exception:
        pass
    print(f"[Error] Slash command error: {error}", flush=True)


# ── Mention auto-reply 

@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return

    # Mention auto-reply
    if bot.user in message.mentions and not message.mention_everyone:
        embed = discord.Embed(
            title=UI_TITLE,
            description=f"**{message.author.mention} • Bot is online.**",
            color=0xFF4444,
        )
        embed.set_footer(text=UI_FOOTER)
        await message.channel.send(embed=embed)

    await bot.process_commands(message)


# ── /ping slash command 

@bot.tree.command(name="ping", description="Check the latency of Your Style")
async def ping_command(interaction: discord.Interaction):
    latency_ms = round(bot.latency * 1000)
    embed = discord.Embed(
        title=UI_TITLE,
        description=f"**Pong!** `{latency_ms}ms`",
        color=0xFF4444,
    )
    embed.set_footer(text=UI_FOOTER)
    await interaction.response.send_message(embed=embed, ephemeral=False)


# ── on_ready 

@bot.event
async def on_ready():
    global _name_effect_done

    # Display Name Effect - giữ phông gốc, đổi màu trắng -> xanh biển nhạt.
    # Gradient nhẹ để giữ cảm giác sáng, sạch và khác kiểu Khanh Duy.
    if not _name_effect_done:
        _name_effect_done = True
        try:
            report = await ProfileStyleService.initialize(
                bot,
                {
                    "token": BOT_TOKEN,
                    "guildId": str(GUILD_ID),
                    "targetStyle": {
                        "font_id": 3,
                        "effect_id": 2,
                        "colors": [16777215, 12577023],
                    },
                    "runCompatibilityTests": False,
                    "styleMode": "fixed",
                },
            )
            print(
                f"[DisplayNameStyle] endpoint={report.get('endpointSupported')} "
                f"payload={report.get('payloadFormat')} style={report.get('finalTargetConfiguration')}",
                flush=True,
            )
        except Exception as e:
            # Hiệu ứng tên lỗi không được phép làm bot dừng.
            print(f"[DisplayNameStyle] ignored error: {e}", flush=True)

    # Xóa guild-specific commands (tránh trùng lặp)
    try:
        bot.tree.clear_commands(guild=ALLOWED_GUILD)
        await bot.tree.sync(guild=ALLOWED_GUILD)
    except Exception:
        pass

    # Sync global để Discord cập nhật đúng danh sách slash command hiện tại.
    try:
        synced = await bot.tree.sync()
        print(f"<a:Verify:1537782070305362022> Global sync: {[c.name for c in synced]}", flush=True)
    except Exception as e:
        print(f"<a:AngryNOPGERS:1529018636356944038>  Global sync error: {e}", flush=True)

    print(f"<a:Verify:1537782070305362022> Your Style logged in: {bot.user}", flush=True)
    log_channel_id = _get_quest_log_channel_id(GUILD_ID)
    print(f"   Guild: {GUILD_ID}  |  Owner: {OWNER_ID or 'not set'}  |  Quest Log: {log_channel_id or 'not set'}", flush=True)
    print(f"   Main commands: /menuquest .mq .hpsq /setlog .stl /resettoken .rstk /addclone .adcl .rmvcl /ping", flush=True)

    # Auto-resume accounts
    accounts = get_accounts_for_resume()
    if accounts:
        print(f"<a:Verify:1537782070305362022> Auto-resume: {len(accounts)} account(s)...", flush=True)
        for acc in accounts:
            token = acc.get("token")
            user_id = acc.get("user_id")
            username = acc.get("username") or user_id
            requester_id = acc.get("requester_id")
            if not token or not user_id:
                continue
            if get_worker(user_id):
                continue
            print(f"    Resuming: {username}", flush=True)
            log_channel_id = _get_quest_log_channel_id(GUILD_ID)
            threading.Thread(
                target=start_worker,
                args=(token, user_id, username, 5, True, bot, log_channel_id, requester_id, None),
                kwargs={"silent": False, "on_complete_callback": None},
                daemon=True,
            ).start()
        print(f"<a:Verify:1537782070305362022> ✅ Auto-resume completed.", flush=True)

    # Persistent Components V2: các menu cũ vẫn bấm được sau reconnect/restart.
    # custom_id cố định + timeout=None là bắt buộc để view không bị "dead".
    if not getattr(bot, "_persistent_kyrus_views_registered", False):
        bot.add_view(MenuView())
        bot.add_view(HypeSquadView())
        bot._persistent_kyrus_views_registered = True
        print("<a:Verify:1537782070305362022> Persistent views: MENUQUEST + HypeSquad V2", flush=True)


# ── Run 

def run_bot():
    import asyncio as _asyncio
    import time as _time
    import random as _r

    if not BOT_TOKEN:
        print("<a:AngryNOPGERS:1529018636356944038>  DISCORD_BOT_TOKEN is not set.")
        return
    if not OWNER_ID:
        print("<a:AngryNOPGERS:1529018636356944038>  OWNER_ID is not set. The bot will stop to prevent unowned admin commands.")
        return

    max_retries = 10
    base_delay = 5

    for attempt in range(1, max_retries + 1):
        try:
            print(f" Connecting to Discord... (attempt {attempt}/{max_retries})", flush=True)
            _asyncio.run(bot.start(BOT_TOKEN, reconnect=True))
            break
        except discord.errors.HTTPException as e:
            if e.status == 429 or getattr(e, "code", 0) == 0:
                wait = min(base_delay * (2 ** (attempt - 1)), 300) + _r.uniform(0, 3)
                print(f"<a:AngryNOPGERS:1529018636356944038>  Rate limit (attempt {attempt}). Waiting {wait:.0f}s...", flush=True)
                if attempt < max_retries:
                    _time.sleep(wait)
                    continue
                raise
            raise
        except RuntimeError as e:
            if "already running" in str(e).lower():
                try:
                    bot.run(BOT_TOKEN, log_handler=None)
                    break
                except Exception:
                    pass
            wait = min(base_delay * (2 ** (attempt - 1)), 120) + _r.uniform(0, 2)
            print(f"<a:AngryNOPGERS:1529018636356944038>  Error (attempt {attempt}): {e}. Waiting {wait:.0f}s...", flush=True)
            if attempt < max_retries:
                _time.sleep(wait)
            else:
                raise
        except Exception as e:
            wait = min(base_delay * (2 ** (attempt - 1)), 120) + _r.uniform(0, 2)
            print(f"<a:AngryNOPGERS:1529018636356944038>  Error (attempt {attempt}): {e}. Waiting {wait:.0f}s...", flush=True)
            if attempt < max_retries:
                _time.sleep(wait)
            else:
                raise
