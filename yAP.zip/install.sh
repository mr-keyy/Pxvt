#!/bin/bash
# Your Style — Install Script for Pterodactyl
set -e

echo "=== Your Style ==="

# Check Python
if ! command -v python3 &>/dev/null; then
    echo "[ERROR] Python 3 not found. Please use a Python 3.11+ egg image."
    exit 1
fi

PYTHON=$(command -v python3.11 || command -v python3 || echo "python3")
echo "[*] Python: $($PYTHON --version)"

# Create virtualenv if not exists
if [ ! -d ".venv" ]; then
    echo "[*] Creating virtualenv..."
    $PYTHON -m venv .venv
fi

# Upgrade pip
echo "[*] Upgrading pip..."
.venv/bin/pip install --upgrade pip --quiet

# Install requirements
echo "[*] Installing requirements..."
.venv/bin/pip install -r requirements.txt --quiet

echo "[OK] Installation complete!"
echo "     Start with: .venv/bin/python3 main.py"
