#!/bin/bash
# Your Style - Pterodactyl Startup Script
# Compatible with Python 3.11+

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "======================================"
echo "  Your Style"
echo "  Your Style"
echo "======================================"

# Check Python version
PYTHON_BIN=""
for cmd in python3.11 python3.12 python3 python; do
    if command -v "$cmd" &>/dev/null; then
        VER=$("$cmd" -c "import sys; print(sys.version_info[:2] >= (3,11))" 2>/dev/null)
        if [ "$VER" = "True" ]; then
            PYTHON_BIN="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON_BIN" ]; then
    echo "[ERROR] Python 3.11+ not found. Please install Python 3.11 or newer."
    exit 1
fi

echo "[INFO] Using Python: $($PYTHON_BIN --version)"

# Install / upgrade dependencies
echo "[INFO] Installing dependencies..."
"$PYTHON_BIN" -m pip install --upgrade pip --quiet
"$PYTHON_BIN" -m pip install -r requirements.txt --quiet

# Check required environment variables
REQUIRED_VARS="DISCORD_BOT_TOKEN DISCORD_GUILD_ID OWNER_ID"
MISSING=0
for VAR in $REQUIRED_VARS; do
    if [ -z "${!VAR}" ]; then
        # Try loading from .env if not in environment
        if [ -f ".env" ]; then
            export $(grep -v '^#' .env | grep "$VAR" | xargs) 2>/dev/null || true
        fi
        if [ -z "${!VAR}" ]; then
            echo "[WARN] $VAR is not set. Check your .env file or Pterodactyl environment variables."
            MISSING=$((MISSING + 1))
        fi
    fi
done

if [ "$MISSING" -gt 0 ]; then
    echo "[ERROR] $MISSING required variable(s) missing. Check .env (DISCORD_BOT_TOKEN, DISCORD_GUILD_ID and OWNER_ID)."
    exit 1
fi

echo "[INFO] All required environment variables are set."
echo "[INFO] Starting Your Style..."
echo ""

exec "$PYTHON_BIN" main.py
