#!/usr/bin/env python3


import os
import sys
import io
import logging

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

from dotenv import load_dotenv

_base = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(_base, ".env"))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("kyrus")


import database

database.init_db()
log.info(f"✅ Database: {database.DB_PATH}")

from bot import run_bot, BOT_TOKEN

def main():
    if not BOT_TOKEN:
        log.error("❌ DISCORD_BOT_TOKEN is not set!")
        log.error("   Add the token to Secrets with key: DISCORD_BOT_TOKEN")
        sys.exit(1)

    log.info("Starting Your Style...")
    log.info(" Commands: /menuquest .mq .hpsq /setlog .stl /resettoken .rstk /ping .adcl /addclone")
    run_bot()


if __name__ == "__main__":
    main()
