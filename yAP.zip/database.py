"""
Your Style - Database module
SQLite database for storing accounts, sessions, quest logs, and settings.
"""

import sqlite3
import os
import requests
from datetime import datetime, timezone
from contextlib import contextmanager

# DB lưu ở ~/.kyrus_bot/ để không bị xóa khi update bot
# Có thể override bằng env var DB_PATH nếu muốn đường dẫn khác
_default_db_dir = os.path.join(os.path.expanduser("~"), ".kyrus_bot")
os.makedirs(_default_db_dir, exist_ok=True)
DB_PATH = os.environ.get(
    "DB_PATH",
    os.path.join(_default_db_dir, "bot_data.db"),
)


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS accounts (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id          TEXT    NOT NULL UNIQUE,
                username         TEXT,
                discriminator    TEXT,
                global_name      TEXT,
                added_at         TEXT    NOT NULL,
                status           TEXT    NOT NULL DEFAULT 'offline',
                last_seen        TEXT,
                manually_stopped INTEGER NOT NULL DEFAULT 0,
                requester_id     TEXT
            );

            CREATE TABLE IF NOT EXISTS tokens (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id   INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
                token        TEXT    NOT NULL UNIQUE,
                build_number INTEGER,
                added_at     TEXT    NOT NULL,
                last_error   TEXT
            );

            CREATE TABLE IF NOT EXISTS sessions (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                token_id   INTEGER NOT NULL REFERENCES tokens(id) ON DELETE CASCADE,
                started_at TEXT    NOT NULL,
                stopped_at TEXT,
                reason     TEXT
            );

            CREATE TABLE IF NOT EXISTS quest_log (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                token_id   INTEGER NOT NULL REFERENCES tokens(id) ON DELETE CASCADE,
                quest_name TEXT,
                quest_id   TEXT,
                task_type  TEXT,
                action     TEXT    NOT NULL,
                status     TEXT    NOT NULL DEFAULT 'pending',
                message    TEXT,
                created_at TEXT    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT
            );
        """)
        conn.commit()
        # Migrations: thêm cột nếu chưa có (DB cũ)
        for migration in [
            "ALTER TABLE accounts ADD COLUMN manually_stopped INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE accounts ADD COLUMN requester_id TEXT",
        ]:
            try:
                conn.execute(migration)
                conn.commit()
            except Exception:
                pass


# ── Account management ────────────────────────────────────────────────────────

def validate_token(token: str) -> dict | None:
    """Gọi Discord API kiểm tra token. Trả về user info dict nếu hợp lệ, None nếu không."""
    try:
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        }
        r = requests.get("https://discord.com/api/v9/users/@me", headers=headers, timeout=10)
        if r.status_code == 200:
            return r.json()
        return None
    except Exception:
        return None


def add_account(token: str, build_number: int = None, requester_id: str = None) -> dict | None:
    """Validate token rồi lưu vào DB. Trả về dict account info hoặc None nếu token sai."""
    user_info = validate_token(token)
    if not user_info:
        return None

    user_id = user_info.get("id", "unknown")
    username = user_info.get("username")
    discriminator = user_info.get("discriminator")
    global_name = user_info.get("global_name")
    now = datetime.now(timezone.utc).isoformat()
    rid = requester_id or user_id

    with get_conn() as conn:
        # Tìm account theo requester_id trước
        row = conn.execute(
            "SELECT id FROM accounts WHERE requester_id = ?", (rid,)
        ).fetchone()

        if row:
            account_id = row["id"]
            conn.execute(
                "UPDATE accounts SET user_id=?, username=?, last_seen=?, manually_stopped=0 WHERE id=?",
                (user_id, username, now, account_id)
            )
        else:
            # Tìm theo user_id từ token
            row2 = conn.execute(
                "SELECT id FROM accounts WHERE user_id = ?", (user_id,)
            ).fetchone()
            if row2:
                account_id = row2["id"]
                conn.execute(
                    "UPDATE accounts SET last_seen=?, requester_id=?, manually_stopped=0 WHERE id=?",
                    (now, rid, account_id)
                )
            else:
                cur = conn.execute(
                    """INSERT INTO accounts
                       (user_id, username, discriminator, global_name, added_at, status, last_seen, requester_id)
                       VALUES (?, ?, ?, ?, ?, 'offline', ?, ?)""",
                    (user_id, username, discriminator, global_name, now, now, rid)
                )
                account_id = cur.lastrowid

        # Cập nhật hoặc thêm token
        trow = conn.execute(
            "SELECT id FROM tokens WHERE account_id = ?", (account_id,)
        ).fetchone()
        if trow:
            conn.execute(
                "UPDATE tokens SET token=?, last_error=NULL WHERE id=?",
                (token, trow["id"])
            )
            token_id = trow["id"]
        else:
            cur2 = conn.execute(
                "INSERT INTO tokens (account_id, token, build_number, added_at) VALUES (?, ?, ?, ?)",
                (account_id, token, build_number, now)
            )
            token_id = cur2.lastrowid

        conn.commit()
        return {
            "account_id": account_id,
            "token_id": token_id,
            "user_id": user_id,
            "username": username,
            "global_name": global_name,
            "token": token,
            "requester_id": rid,
        }


def get_account_by_requester(requester_id: str) -> dict | None:
    """Lấy account của Discord user theo requester_id."""
    with get_conn() as conn:
        row = conn.execute("""
            SELECT a.*, t.token, t.build_number, t.last_error
            FROM accounts a
            LEFT JOIN tokens t ON t.account_id = a.id
            WHERE a.requester_id = ?
            ORDER BY t.added_at DESC
            LIMIT 1
        """, (requester_id,)).fetchone()
        return dict(row) if row else None


def remove_account(user_id: str) -> bool:
    with get_conn() as conn:
        cur = conn.execute("SELECT id FROM accounts WHERE user_id = ?", (user_id,))
        row = cur.fetchone()
        if not row:
            return False
        conn.execute("DELETE FROM accounts WHERE id = ?", (row["id"],))
        conn.commit()
        return True


def remove_account_by_requester(requester_id: str) -> bool:
    """Xóa token/account theo requester_id (Discord user ID của người dùng bot)."""
    with get_conn() as conn:
        row = conn.execute(
            "SELECT id, user_id FROM accounts WHERE requester_id = ?", (requester_id,)
        ).fetchone()
        if not row:
            return False
        conn.execute("DELETE FROM accounts WHERE id = ?", (row["id"],))
        conn.commit()
        return True


def get_all_accounts() -> list:
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT a.*, t.token, t.build_number, t.last_error,
                   s.id as session_id, s.started_at, s.stopped_at
            FROM accounts a
            LEFT JOIN tokens t ON t.account_id = a.id
            LEFT JOIN (
                SELECT token_id, id, started_at, stopped_at,
                       ROW_NUMBER() OVER (PARTITION BY token_id ORDER BY started_at DESC) as rn
                FROM sessions
            ) s ON s.token_id = t.id AND s.rn = 1
            ORDER BY a.added_at DESC
        """).fetchall()
        return [dict(r) for r in rows]


def update_account_status(user_id: str, status: str):
    with get_conn() as conn:
        conn.execute(
            "UPDATE accounts SET status = ?, last_seen = ? WHERE user_id = ?",
            (status, datetime.now(timezone.utc).isoformat(), user_id)
        )
        conn.commit()


def set_manually_stopped(user_id: str, stopped: bool):
    with get_conn() as conn:
        conn.execute(
            "UPDATE accounts SET manually_stopped = ? WHERE user_id = ?",
            (1 if stopped else 0, user_id)
        )
        conn.commit()


def get_accounts_for_resume() -> list:
    """Chỉ lấy tài khoản hợp lệ chưa bị dừng thủ công để auto-resume."""
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT a.*, t.token
            FROM accounts a
            INNER JOIN tokens t ON t.account_id = a.id
            WHERE a.manually_stopped = 0
              AND a.user_id != 'unknown'
              AND a.user_id IS NOT NULL
              AND t.token IS NOT NULL
              AND t.token != ''
            ORDER BY a.added_at DESC
        """).fetchall()
        return [dict(r) for r in rows]


# ── Session management ────────────────────────────────────────────────────────

def start_session(token_id: int) -> int:
    now = datetime.now(timezone.utc).isoformat()
    with get_conn() as conn:
        conn.execute(
            "UPDATE sessions SET stopped_at = ?, reason = 'auto' WHERE token_id = ? AND stopped_at IS NULL",
            (now, token_id)
        )
        cur = conn.execute(
            "INSERT INTO sessions (token_id, started_at) VALUES (?, ?)",
            (token_id, now)
        )
        conn.commit()
        return cur.lastrowid


def stop_session(session_id: int, reason: str = "manual"):
    now = datetime.now(timezone.utc).isoformat()
    with get_conn() as conn:
        conn.execute(
            "UPDATE sessions SET stopped_at = ?, reason = ? WHERE id = ?",
            (now, reason, session_id)
        )
        conn.commit()


# ── Quest log ────────────────────────────────────────────────────────────────

def log_quest(token_id: int, quest_name: str, quest_id: str,
              task_type: str, action: str, status: str = "pending", message: str = ""):
    now = datetime.now(timezone.utc).isoformat()
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO quest_log (token_id, quest_name, quest_id, task_type, action, status, message, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (token_id, quest_name, quest_id, task_type, action, status, message, now)
        )
        conn.commit()


# ── Settings ──────────────────────────────────────────────────────────────────

def get_setting(key: str, default=None):
    with get_conn() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else default


def set_setting(key: str, value: str):
    with get_conn() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
            (key, value)
        )
        conn.commit()


