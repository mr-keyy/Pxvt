"""
Your Style - Worker thread
Runs quest auto-completion for a single Discord account.
"""

import asyncio
import threading
import concurrent.futures
import time
import random
import base64
import json as _json
import gc
import requests
from requests.adapters import HTTPAdapter
from datetime import datetime, timezone
from typing import Optional

from database import (
    start_session, stop_session, log_quest, update_account_status
)

API_BASE = "https://discord.com/api/v9"
UI_TITLE = "Your Style"
UI_FOOTER = "Your Style"
HEARTBEAT_INTERVAL = 20.0  # Giữ nguyên heartbeat Discord

# ── Quest performance profile (fixed; no .env tuning) ─────────────────────────
QUEST_POLL_INTERVAL = 5
QUEST_MAX_WORKERS = 3
QUEST_VIDEO_REQUEST_INTERVAL = 15.0
QUEST_LIVE_UPDATE_INTERVAL = 5.0
QUEST_SYNC_INTERVAL = 30.0
QUEST_ACTION_DELAY = 15.0
QUEST_ENROLL_DELAY_MIN = 0.5
QUEST_ENROLL_DELAY_MAX = 1.0

# ── Global rate-limit throttle ─────────────────────────────────────────────────
_last_request_time: float = 0.0
_request_lock = threading.Lock()
_MIN_REQUEST_GAP = 0.3
SUPPORTED_TASKS = [
    "WATCH_VIDEO",
    "WATCH_VIDEO_ON_MOBILE",
    "PLAY_ON_DESKTOP",
    "STREAM_ON_DESKTOP",
    "PLAY_ACTIVITY",
]
VIDEO_TASKS = {"WATCH_VIDEO", "WATCH_VIDEO_ON_MOBILE"}

# ── Build number cache ────────────────────────────────────────────────────────
_cached_build: int = 0
_cached_build_ts: float = 0.0
_BUILD_TTL = 1800  # 30 phút


# ── Helpers ───────────────────────────────────────────────────────────────────

def _get(d, *keys):
    if d is None:
        return None
    for k in keys:
        if k in d:
            return d[k]
    return None


def fetch_latest_build_number() -> int:
    global _cached_build, _cached_build_ts
    if _cached_build and (time.time() - _cached_build_ts) < _BUILD_TTL:
        return _cached_build

    FALLBACK = 504649
    import re
    try:
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128.0.0.0 Safari/537.36"
        r = requests.get("https://discord.com/app", headers={"User-Agent": ua}, timeout=15)
        if r.status_code != 200:
            return _cached_build or FALLBACK
        scripts = re.findall(r'/assets/([a-f0-9]+)\.js', r.text)
        if not scripts:
            scripts_alt = re.findall(r'src="(/assets/[^"]+\.js)"', r.text)
            scripts = [s.split('/')[-1].replace('.js', '') for s in scripts_alt]
        if not scripts:
            return _cached_build or FALLBACK
        for asset_hash in scripts[-5:]:
            try:
                ar = requests.get(
                    f"https://discord.com/assets/{asset_hash}.js",
                    headers={"User-Agent": ua}, timeout=15
                )
                m = re.search(r'buildNumber["\s:]+["\s]*(\d{5,7})', ar.text)
                if m:
                    _cached_build = int(m.group(1))
                    _cached_build_ts = time.time()
                    return _cached_build
            except Exception:
                continue
        return _cached_build or FALLBACK
    except Exception:
        return _cached_build or FALLBACK


def make_super_properties(build_number: int) -> str:
    obj = {
        "os": "Windows",
        "browser": "Discord Client",
        "release_channel": "stable",
        "client_version": "1.0.9175",
        "os_version": "10.0.26100",
        "os_arch": "x64",
        "app_arch": "x64",
        "system_locale": "en-US",
        "browser_user_agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "discord/1.0.9175 Chrome/128.0.6613.186 "
            "Electron/32.2.7 Safari/537.36"
        ),
        "browser_version": "32.2.7",
        "client_build_number": build_number,
        "native_build_number": 59498,
        "client_event_source": None,
    }
    return base64.b64encode(_json.dumps(obj).encode()).decode()


def _throttle_request():
    """Ensure at least _MIN_REQUEST_GAP seconds between API requests."""
    global _last_request_time
    with _request_lock:
        now = time.time()
        gap = now - _last_request_time
        if gap < _MIN_REQUEST_GAP:
            time.sleep(_MIN_REQUEST_GAP - gap + random.uniform(0, 0.1))
        _last_request_time = time.time()


class WorkerAPI:
    def __init__(self, token: str, build_number: int):
        self.token = token
        self.session = requests.Session()
        # Giới hạn connection pool để tiết kiệm RAM (mỗi account ~2 connections là đủ)
        _adapter = HTTPAdapter(
            pool_connections=2,
            pool_maxsize=4,
            max_retries=0,
        )
        self.session.mount("https://", _adapter)
        self.session.mount("http://", _adapter)
        ua = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "discord/1.0.9175 Chrome/128.0.6613.186 "
            "Electron/32.2.7 Safari/537.36"
        )
        sp = make_super_properties(build_number)
        self.session.headers.update({
            "Authorization": token,
            "Content-Type": "application/json",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "User-Agent": ua,
            "X-Super-Properties": sp,
            "X-Discord-Locale": "en-US",
            "X-Discord-Timezone": "Asia/Ho_Chi_Minh",
            "Origin": "https://discord.com",
            "Referer": "https://discord.com/channels/@me",
        })

    def close(self):
        """Close the session to free RAM."""
        try:
            self.session.close()
        except Exception:
            pass

    def get(self, path: str, retries: int = 3):
        _throttle_request()
        for attempt in range(retries):
            try:
                r = self.session.get(f"{API_BASE}{path}", timeout=20)
                if r.status_code == 429:
                    try:
                        wait = r.json().get("retry_after", 5)
                    except Exception:
                        wait = 5
                    wait = min(float(wait), 30)
                    time.sleep(wait + random.uniform(0.5, 1.5))
                    continue
                return r
            except requests.exceptions.RequestException as e:
                if attempt < retries - 1:
                    time.sleep(2 ** attempt + random.uniform(0, 1))
                    continue
                raise
        return self.session.get(f"{API_BASE}{path}", timeout=20)

    def post(self, path: str, payload=None, extra_headers: dict = None, retries: int = 3):
        _throttle_request()
        for attempt in range(retries):
            try:
                r = self.session.post(f"{API_BASE}{path}", json=payload, headers=extra_headers, timeout=20)
                if r.status_code == 429:
                    try:
                        wait = r.json().get("retry_after", 5)
                    except Exception:
                        wait = 5
                    wait = min(float(wait), 30)
                    time.sleep(wait + random.uniform(0.5, 1.5))
                    continue
                return r
            except requests.exceptions.RequestException as e:
                if attempt < retries - 1:
                    time.sleep(2 ** attempt + random.uniform(0, 1))
                    continue
                raise
        return self.session.post(f"{API_BASE}{path}", json=payload, headers=extra_headers, timeout=20)


# ── Quest helpers ─────────────────────────────────────────────────────────────

def get_task_config(quest):
    cfg = quest.get("config", {})
    for key in ("taskConfig", "task_config", "taskConfigV2", "task_config_v2"):
        val = cfg.get(key)
        if val:
            return val
    if "tasks" in cfg:
        return cfg
    return None


def get_quest_name(quest):
    cfg = quest.get("config", {})
    msgs = cfg.get("messages", {})
    name = _get(msgs, "questName", "quest_name")
    if name:
        return name.strip()
    game = _get(msgs, "gameTitle", "game_title")
    if game:
        return game.strip()
    return f"Quest#{quest.get('id', '?')}"


def get_expires_at(quest):
    cfg = quest.get("config", {})
    return _get(cfg, "expiresAt", "expires_at")


def is_expired_quest(quest) -> bool:
    tc = get_task_config(quest)
    if not tc or "tasks" not in tc:
        return False
    if not any(tc["tasks"].get(t) is not None for t in SUPPORTED_TASKS):
        return False
    expires = get_expires_at(quest)
    if not expires:
        return False
    try:
        exp_dt = datetime.fromisoformat(expires.replace("Z", "+00:00"))
        return exp_dt <= datetime.now(timezone.utc)
    except Exception:
        return False


def get_user_status(quest):
    us = _get(quest, "userStatus", "user_status")
    return us if isinstance(us, dict) else {}


def is_completable(quest) -> bool:
    expires = get_expires_at(quest)
    if expires:
        try:
            exp_dt = datetime.fromisoformat(expires.replace("Z", "+00:00"))
            if exp_dt <= datetime.now(timezone.utc):
                return False
        except Exception:
            pass
    tc = get_task_config(quest)
    if not tc:
        return False
    tasks = tc.get("tasks", {})
    if not tasks:
        return False
    return any(tasks.get(t) is not None for t in SUPPORTED_TASKS)


def is_enrolled(quest) -> bool:
    us = get_user_status(quest)
    return bool(_get(us, "enrolledAt", "enrolled_at"))


def is_completed(quest) -> bool:
    us = get_user_status(quest)
    return bool(_get(us, "completedAt", "completed_at"))


def get_task_type(quest) -> Optional[str]:
    tc = get_task_config(quest)
    if not tc:
        return None
    tasks = tc.get("tasks", {})
    for t in SUPPORTED_TASKS:
        if tasks.get(t) is not None:
            return t
    return None


def get_seconds_needed(quest) -> float:
    tc = get_task_config(quest)
    task_type = get_task_type(quest)
    if not tc or not task_type:
        return 0
    task_data = tc.get("tasks", {}).get(task_type)
    if isinstance(task_data, dict):
        # Thử nhiều tên field khác nhau mà Discord dùng
        for key in ("target", "duration", "seconds", "time",
                    "durationSeconds", "duration_seconds", "totalSeconds", "total_seconds"):
            if key in task_data and task_data[key]:
                return float(task_data[key])
    elif isinstance(task_data, (int, float)) and task_data:
        return float(task_data)
    return 0


def get_seconds_done(quest) -> float:
    task_type = get_task_type(quest)
    if not task_type:
        return 0
    us = get_user_status(quest)
    progress = us.get("progress", {})
    val = progress.get(task_type, {})
    if isinstance(val, dict):
        return float(val.get("value", 0))
    return 0


def get_enrolled_at(quest):
    us = get_user_status(quest)
    return _get(us, "enrolledAt", "enrolled_at")


# ── Worker ─────────────────────────────────────────────────────────────────────

_SPIN = ["🌀", "⚡", "💫", "✨", "🔥", "💙", "🌟", "⚡"]


class QuestWorker(threading.Thread):
    def __init__(self, token: str, user_id: str, username: str,
                 poll_interval: int = 5, auto_accept: bool = True,
                 stop_event: threading.Event = None,
                 bot_client=None, channel_id: int = None,
                 requester_discord_id: str = None, avatar_url: str = None,
                 silent: bool = False, on_complete_callback=None,
                 pre_channel_msg=None):
        super().__init__(daemon=True)
        self.token = token
        self.user_id = user_id
        self.username = username
        self.poll_interval = max(int(poll_interval or 0), QUEST_POLL_INTERVAL)
        self.auto_accept = auto_accept
        self._stop = stop_event or threading.Event()
        self._api: Optional[WorkerAPI] = None
        self._build_number = 0
        self._session_id: Optional[int] = None
        self._completed_ids: set = set()
        self._running = False
        self._last_status = "idle"
        self._status_msg = "Starting..."
        self._bot = bot_client
        self._channel_id = channel_id
        self._requester_discord_id = requester_discord_id
        self._avatar_url = avatar_url
        self._quest_map: dict = {}
        self._dm_msg = None
        self._channel_status_msg = pre_channel_msg   # pre-created message (single GUI)
        self._current_quest: Optional[str] = None
        self._completion_sent: bool = False
        self._silent: bool = silent
        self._on_complete_callback = on_complete_callback
        self._notified_start: bool = False
        self._final_stats: dict = {}
        self._skip_ids: set = set()
        self._live_updater_active: bool = False
        self._dm_lock = threading.Lock()
        self._ch_lock = threading.Lock()
        self._lock = threading.Lock()          # Bảo vệ completed_ids khỏi race condition
        self._retry_counts: dict = {}  # quest_id -> retry count
        self._spin_idx: int = 0        # emoji animation index

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def status(self) -> str:
        return self._last_status

    @property
    def status_message(self) -> str:
        return self._status_msg

    def _log(self, msg: str, level: str = "info"):
        ts = datetime.now().strftime("%H:%M:%S")
        prefix = {
            "info":     f"[{self.username}][INFO]   ",
            "ok":       f"[{self.username}][  OK]   ",
            "warn":     f"[{self.username}][WARN]   ",
            "error":    f"[{self.username}][ ERR]   ",
            "progress": f"[{self.username}][PROG]   ",
        }.get(level, f"[{self.username}][{level.upper()}]")
        print(f"{ts} {prefix} {msg}", flush=True)

    # ── Discord notification helpers ───────────────────────────────────────────

    def _run_async_nowait(self, coro):
        if not self._bot or not getattr(self._bot, "loop", None):
            return
        try:
            asyncio.run_coroutine_threadsafe(coro, self._bot.loop)
        except Exception as e:
            self._log(f"Async error: {e}", "warn")

    @staticmethod
    def _bar(done: float, total: float, width: int = 10) -> str:
        if total <= 0:
            return "`░░░░░░░░░░` 0%"
        pct = min(done / total, 1.0)
        filled = int(pct * width)
        bar = "█" * filled + "░" * (width - filled)
        pct_str = f"{pct*100:.0f}%"
        if total >= 60:
            d_min, d_sec = divmod(int(done), 60)
            t_min, t_sec = divmod(int(total), 60)
            time_str = f"{d_min}:{d_sec:02d}/{t_min}:{t_sec:02d}"
        else:
            time_str = f"{int(done)}/{int(total)}s"
        return f"`{bar}` **{pct_str}** · ⏱ {time_str}"

    def _build_status_embed(self, completed_all: bool = False):
        import discord as _discord
        total         = len(self._quest_map)
        done_count    = sum(1 for v in self._quest_map.values() if v["status"] == "done")
        running_count = sum(1 for v in self._quest_map.values() if v["status"] == "running")
        pending_count = total - done_count

        # Rotate spin emoji for animation feel
        self._spin_idx = (self._spin_idx + 1) % len(_SPIN)
        spin = _SPIN[self._spin_idx]

        if completed_all:
            title = "Your Style"
            color = 0x00BFFF
        elif total == 0:
            title = "Your Style"
            color = 0xFFA500
        elif running_count > 0:
            title = "Your Style"
            color = 0x00BFFF
        elif pending_count > 0:
            title = "Your Style"
            color = 0xFFA500
        else:
            title = "Your Style"
            color = 0x00BFFF

        embed = _discord.Embed(title=UI_TITLE, color=color)

        # Only show quests that are NOT done
        lines = []
        for info in self._quest_map.values():
            name = info["name"]
            st   = info["status"]
            sd   = info.get("seconds_done", 0)
            sn   = info.get("seconds_needed", 0)

            if st == "done":
                continue  # ← Không hiện quest đã completed
            elif st == "running":
                if sn > 0:
                    lines.append(f"⚡ **{name}**\n　{self._bar(sd, sn)}")
                else:
                    lines.append(f"⚡ **{name}** · processing...")
            elif st == "enrolling":
                lines.append(f"🎯 **{name}** · enrolling...")
            elif st == "failed":
                retry = self._retry_counts.get(name, 0)
                lines.append(f"❌ **{name}** · failed ({retry}x retry)")
            else:  # waiting
                lines.append(f"⏳ **{name}** · waiting")

        if lines:
            embed.add_field(name="📋 Active quests", value="\n".join(lines[:10]), inline=False)
        elif completed_all:
            embed.add_field(
                name="🏆 Perfect! All completed",
                value="✨ Go to **Discord Settings** → **Gifts** to claim your reward",
                inline=False,
            )
        elif done_count == total and total > 0:
            embed.add_field(
                name="🏆 All quests completed!",
                value="✨ No quests left to complete",
                inline=False,
            )

        if self._avatar_url:
            embed.set_thumbnail(url=self._avatar_url)
        now_str = datetime.now().strftime("%H:%M:%S")
        embed.set_footer(text=UI_FOOTER)
        return embed

    def _start_live_updater(self):
        if self._live_updater_active:
            return
        self._live_updater_active = True

        def _sync_real_progress():
            """Sync seconds_done from the Discord API every 30 seconds to reduce load."""
            while not self._stop.is_set() and self._live_updater_active:
                time.sleep(QUEST_SYNC_INTERVAL)
                if self._stop.is_set() or not self._api:
                    break
                try:
                    r = self._api.get("/quests/@me")
                    if r.status_code != 200:
                        continue
                    data = r.json()
                    ql = data.get("quests", []) if isinstance(data, dict) else data
                    if not isinstance(ql, list):
                        continue
                    for q in ql:
                        qid = q.get("id")
                        if qid not in self._quest_map:
                            continue
                        info = self._quest_map[qid]
                        if info["status"] in ("done", "failed"):
                            continue
                        # Đọc progress thật từ Discord
                        real_done = get_seconds_done(q)
                        real_needed = get_seconds_needed(q)
                        # Nếu Discord đã xác nhận hoàn thành (completed_at), set 100%
                        if is_completed(q):
                            info["seconds_done"] = real_needed if real_needed > 0 else real_done
                            info["status"] = "done"
                        else:
                            if real_done > 0:
                                info["seconds_done"] = real_done
                            if real_needed > 0:
                                info["seconds_needed"] = real_needed
                except Exception:
                    pass

        def _loop():
            while not self._stop.is_set() and self._live_updater_active:
                time.sleep(QUEST_LIVE_UPDATE_INTERVAL)
                if self._stop.is_set():
                    break
                if self._quest_map:
                    self._send_both_update()

        threading.Thread(target=_sync_real_progress, daemon=True, name=f"sync-{self.username}").start()
        threading.Thread(target=_loop, daemon=True, name=f"live-{self.username}").start()

    def _send_start_ping(self):
        """Create one DM status message and edit that same message afterward."""
        self._send_channel_update()
        if not self._bot or not self._requester_discord_id:
            return
        # Chiếm lock để _send_dm_update không tạo message mới trong khi đang tạo
        if not self._dm_lock.acquire(blocking=False):
            return
        rid = self._requester_discord_id

        async def _do():
            try:
                user = await self._bot.fetch_user(int(rid))
                dm = await user.create_dm()
                embed = self._build_status_embed()   # dùng cùng embed như server
                msg = await dm.send(embed=embed)
                self._dm_msg = msg
            except Exception as e:
                self._log(f"DM start error: {e}", "warn")
            finally:
                self._dm_lock.release()

        self._run_async_nowait(_do())

    def _send_dm_update(self, completed_all: bool = False):
        if not self._bot or not self._requester_discord_id:
            return
        if not self._dm_lock.acquire(blocking=False):
            return   # bỏ qua nếu đang tạo message đầu tiên

        embed = self._build_status_embed(completed_all)   # cùng embed với server
        dm_ref = [self._dm_msg]
        rid = self._requester_discord_id

        async def _do():
            try:
                if dm_ref[0] is None:
                    # Chưa có message → tạo mới (chỉ xảy ra nếu start_ping thất bại)
                    user = await self._bot.fetch_user(int(rid))
                    dm = await user.create_dm()
                    msg = await dm.send(embed=embed)
                    self._dm_msg = msg
                else:
                    # Edit message hiện có → không tạo message mới
                    await dm_ref[0].edit(embed=embed)
            except Exception as e:
                self._log(f"DM error: {e}", "warn")
            finally:
                self._dm_lock.release()

        self._run_async_nowait(_do())

    def _send_channel_update(self, completed_all: bool = False):
        if not self._bot or not self._channel_id or not self._requester_discord_id:
            return
        if not self._ch_lock.acquire(blocking=False):
            return

        embed = self._build_status_embed(completed_all)
        ch_ref = [self._channel_status_msg]
        rid = self._requester_discord_id

        async def _do():
            try:
                if ch_ref[0] is None:
                    ch = self._bot.get_channel(self._channel_id)
                    if not ch:
                        ch = await self._bot.fetch_channel(self._channel_id)
                    msg = await ch.send(content=f"<@{rid}>", embed=embed)
                    self._channel_status_msg = msg
                else:
                    await ch_ref[0].edit(embed=embed)
            except Exception as e:
                self._log(f"Channel update error: {e}", "warn")
            finally:
                self._ch_lock.release()

        self._run_async_nowait(_do())

    def _send_both_update(self, completed_all: bool = False):
        self._send_channel_update(completed_all)
        self._send_dm_update(completed_all)

    def _send_completion_to_channel(self):
        if not self._bot or not self._channel_id or not self._requester_discord_id:
            return
        import discord as _discord
        stats     = self._final_stats
        completed = stats.get("completed", sum(1 for v in self._quest_map.values() if v["status"] == "done"))
        expired   = stats.get("expired", 0)
        total     = stats.get("total", completed + expired)

        embed = _discord.Embed(title=UI_TITLE, color=0x00BFFF)
        embed.add_field(
            name="📊 Status",
            value=(
                f"✅ **{completed}/{total}** completed\n"
                + (f"🔴 **{expired}** expired" if expired else "")
            ),
            inline=False,
        )
        if expired == 0 and completed > 0:
            embed.add_field(name="🏆 Perfect!", value="100% complete — no quests missed!", inline=False)
        embed.add_field(
            name="🎁 Claim reward",
            value="✨ Go to **Discord Settings** → **Gifts** to claim it",
            inline=False,
        )
        if self._avatar_url:
            embed.set_thumbnail(url=self._avatar_url)
        embed.set_footer(text=UI_FOOTER)

        rid      = self._requester_discord_id
        callback = self._on_complete_callback
        ch_msg   = self._channel_status_msg   # pre-created single GUI

        async def _do():
            try:
                if ch_msg:
                    # Edit the single status message with completion embed
                    await ch_msg.edit(content=f"<@{rid}>", embed=embed)
                else:
                    ch = self._bot.get_channel(self._channel_id)
                    if not ch:
                        ch = await self._bot.fetch_channel(self._channel_id)
                    await ch.send(content=f"<@{rid}>", embed=embed)
            except Exception as e:
                self._log(f"Completion error: {e}", "warn")
            # Gọi callback NGAY LẬP TỨC (không delay) — callback này gửi yêu cầu
            # Callback hoàn tất: refresh sticky MENUQUEST.
            # gây gắn oan role nợ xấu for người dùng.
            if callback:
                try:
                    await callback()
                except Exception as e:
                    self._log(f"Menu resend error: {e}", "warn")

        self._run_async_nowait(_do())

    # ── Core ──────────────────────────────────────────────────────────────────

    def _fetch_build(self):
        self._log("Fetching build number...", "info")
        self._build_number = fetch_latest_build_number()
        self._api = WorkerAPI(self.token, self._build_number)
        self._log(f"Build: {self._build_number}", "ok")

    def _fetch_quests(self) -> list:
        try:
            r = self._api.get("/quests/@me")
            if r.status_code == 200:
                data = r.json()
                quests = data.get("quests", []) if isinstance(data, dict) else data
                return quests if isinstance(quests, list) else []
            if r.status_code == 429:
                wait = r.json().get("retry_after", 5)
                self._log(f"Rate limited – waiting {wait}s", "warn")
                time.sleep(wait)
                return self._fetch_quests()
            self._log(f"Quest fetch error ({r.status_code})", "warn")
            return []
        except Exception as e:
            self._log(f"Fetch error: {e}", "error")
            return []

    def _debug_quest(self, q: dict):
        name = get_quest_name(q)
        tc = get_task_config(q)
        if not tc:
            self._log(f'  SKIP "{name}": taskConfig not found', "warn")
            return
        tasks = tc.get("tasks", {})
        if not tasks:
            self._log(f'  SKIP "{name}": tasks are empty — keys={list(tc.keys())}', "warn")
            return
        found = [t for t in tasks if t in SUPPORTED_TASKS]
        if not found:
            self._log(f'  SKIP "{name}": task {list(tasks.keys())} is not in the supported list', "warn")
            return
        expires = get_expires_at(q)
        if expires:
            try:
                exp_dt = datetime.fromisoformat(expires.replace("Z", "+00:00"))
                now = datetime.now(timezone.utc)
                if exp_dt <= now:
                    self._log(
                        f'  SKIP "{name}": expired '
                        f'(expires: {exp_dt.strftime("%d/%m/%Y %H:%M")} UTC, '
                        f'current: {now.strftime("%d/%m/%Y %H:%M")} UTC)', "warn"
                    )
            except Exception as e:
                self._log(f'  SKIP "{name}": failed to parse expiresAt={expires!r}: {e}', "warn")

    def _enroll_quest(self, quest: dict) -> bool:
        name = get_quest_name(quest)
        qid = quest["id"]
        for attempt in range(1, 4):
            try:
                r = self._api.post(f"/quests/{qid}/enroll", {
                    "location": 11,
                    "is_targeted": False,
                    "metadata_raw": None,
                    "metadata_sealed": None,
                    "traffic_metadata_raw": quest.get("traffic_metadata_raw"),
                    "traffic_metadata_sealed": quest.get("traffic_metadata_sealed"),
                })
                if r.status_code == 429:
                    wait = r.json().get("retry_after", 3)
                    self._log(f"Enroll rate limit – waiting {wait}s", "warn")
                    time.sleep(wait)
                    continue
                if r.status_code in (200, 201, 204):
                    self._log(f"✅ Enrolled quest: {name}", "ok")
                    log_quest(self._get_token_id(), name, qid, get_task_type(quest) or "", "enrolled", "success")
                    return True
                if r.status_code == 404:
                    self._log(f"  Enroll {name}: 404 Not Found (quest expired), skipping", "warn")
                    return False
                if r.status_code == 403:
                    self._log(f"  Enroll {name}: 403 Forbidden, skipping", "warn")
                    return False
                self._log(f"Enroll attempt {attempt}/3 failed ({r.status_code}): {r.text[:120]}", "warn")
                if attempt < 3:
                    time.sleep(1)
            except Exception as e:
                self._log(f"Enroll error {attempt}/3: {e}", "error")
                if attempt < 3:
                    time.sleep(1)
        return False

    def _complete_video(self, quest: dict) -> bool:
        """
        Complete video quest:
        1. Try one-shot full timestamp submission
        2. If needed, submit in 7-second steps (time-aware, max_future=10)
        3. Always send a final timestamp to ensure completion
        4. Verify again with the API if needed
        """
        name = get_quest_name(quest)
        qid = quest["id"]
        task_type = get_task_type(quest)
        seconds_needed = get_seconds_needed(quest)
        seconds_done = get_seconds_done(quest)

        alt_task_type = (
            "WATCH_VIDEO_ON_MOBILE" if task_type == "WATCH_VIDEO" else "WATCH_VIDEO"
        )
        tc = get_task_config(quest)
        tasks_dict = tc.get("tasks", {}) if tc else {}
        has_alt = tasks_dict.get(alt_task_type) is not None

        video_headers = {"Referer": f"https://discord.com/quests/{qid}"}

        if seconds_needed <= 0:
            self._log(f"  seconds_needed=0 for {name}, skipping", "warn")
            return False

        if qid in self._quest_map:
            self._quest_map[qid].update(seconds_needed=seconds_needed, seconds_done=seconds_done)

        # enrolled_at để tính thời gian đã trôi
        enrolled_at_str = get_enrolled_at(quest)
        if enrolled_at_str:
            try:
                enrolled_ts = datetime.fromisoformat(enrolled_at_str.replace("Z", "+00:00")).timestamp()
            except Exception:
                enrolled_ts = time.time() - seconds_done  # giả định đã làm được seconds_done giây
        else:
            enrolled_ts = time.time() - seconds_done

        self._log(
            f"Video: {name} ({seconds_done:.0f}/{seconds_needed}s, type={task_type})",
            "progress",
        )

        speed      = 15   # bước tăng timestamp mỗi lần gửi
        max_future = 60   # for phép vượt thời gian thực tối đa 60s
        interval = QUEST_VIDEO_REQUEST_INTERVAL

        def _send_progress(ts: float, use_task: str) -> tuple:
            """
            Send video progress with timestamp ts.
            Returns: (done_seconds, completed_bool, should_bail)
            """
            nonlocal seconds_done
            try:
                r = self._api.post(
                    f"/quests/{qid}/video-progress",
                    {"timestamp": round(ts, 2)},
                    extra_headers=video_headers,
                )
                if r.status_code == 200:
                    body = r.json()
                    prog = body.get("progress", {})
                    updated = seconds_done
                    for key in (use_task, "WATCH_VIDEO", "WATCH_VIDEO_ON_MOBILE"):
                        if key in prog:
                            val = prog[key]
                            updated = float(val.get("value", updated) if isinstance(val, dict) else val)
                            break
                    else:
                        updated = max(seconds_done, ts)
                    seconds_done = updated
                    if qid in self._quest_map:
                        self._quest_map[qid]["seconds_done"] = updated
                    self._log(f"  {name}: {updated:.0f}/{seconds_needed}s", "progress")
                    completed = bool(body.get("completed_at"))
                    return updated, completed, False
                elif r.status_code == 429:
                    try:
                        wait = float(r.json().get("retry_after", 5))
                    except Exception:
                        wait = 5.0
                    self._log(f"Video rate limit – waiting {wait:.0f}s", "warn")
                    time.sleep(wait + 1)
                    return seconds_done, False, False
                elif r.status_code == 404:
                    self._log(f"Video 404: {name}", "warn")
                    return seconds_done, False, True   # bail out
                elif r.status_code == 400:
                    self._log(f"Video 400 ts={ts:.0f}s: {r.text[:60]}", "warn")
                    return seconds_done, False, False
                else:
                    self._log(f"Video-progress {r.status_code}: {r.text[:60]}", "warn")
                    return seconds_done, False, False
            except Exception as e:
                self._log(f"Video progress error: {e}", "error")
                return seconds_done, False, False

        def _do_video(use_task: str) -> bool:
            nonlocal seconds_done
            local_done = seconds_done

            # ── Bước 1: Thử 1-shot full timestamp ────────────────────────────
            if not self._stop.is_set():
                upd, done, bail = _send_progress(float(seconds_needed), use_task)
                local_done = upd
                if bail:
                    return False
                if done:
                    return True

            # ── Bước 2: Gửi từng bước (time-aware) ───────────────────────────
            self._log(f"  Step [{use_task}]: {local_done:.0f}s → {seconds_needed}s", "progress")

            while local_done < seconds_needed and not self._stop.is_set():
                elapsed  = time.time() - enrolled_ts
                max_allowed = elapsed + max_future
                next_ts  = local_done + speed

                # Nếu timestamp tiếp theo vượt quá giới hạn và chưa đủ thời gian, chờ
                if next_ts > max_allowed and next_ts < seconds_needed:
                    time.sleep(interval)
                    continue

                # Gửi timestamp (không vượt quá seconds_needed)
                send_ts = min(next_ts + random.uniform(0, 0.5), seconds_needed)
                upd, done, bail = _send_progress(send_ts, use_task)
                local_done = upd

                if bail:
                    return False
                if done:
                    return True

                # Nếu local_done không tăng từ response, tự tăng để tránh kẹt vô hạn
                if local_done < send_ts - 1:
                    local_done = min(send_ts, seconds_needed)
                    seconds_done = local_done
                    if qid in self._quest_map:
                        self._quest_map[qid]["seconds_done"] = local_done

                if local_done >= seconds_needed:
                    break

                time.sleep(interval)

            # ── Bước 3: Gửi final timestamp đảm bảo hoàn thành ──────────────
            if not self._stop.is_set():
                for attempt in range(3):
                    upd, done, bail = _send_progress(float(seconds_needed), use_task)
                    if done:
                        return True
                    if bail:
                        break
                    if attempt < 2:
                        time.sleep(interval)

            # ── Bước 4: Verify với Discord API ────────────────────────────────
            try:
                r = self._api.get("/quests/@me")
                if r.status_code == 200:
                    data = r.json()
                    ql = data.get("quests", []) if isinstance(data, dict) else data
                    for q in (ql if isinstance(ql, list) else []):
                        if q.get("id") == qid and is_completed(q):
                            return True
            except Exception:
                pass

            return False  # chỉ trả True khi Discord xác nhận completed_at

        # Thử task_type chính
        if _do_video(task_type):
            self._log(f"✅ Video completed [{task_type}]: {name}", "ok")
            if qid in self._quest_map:
                self._quest_map[qid]["seconds_done"] = seconds_needed
            log_quest(self._get_token_id(), name, qid, task_type, "completed", "success")
            return True

        # Thử alt task type
        if has_alt and not self._stop.is_set():
            self._log(f"  Trying fallback [{alt_task_type}] for {name}", "info")
            if _do_video(alt_task_type):
                self._log(f"✅ Video completed [{alt_task_type}]: {name}", "ok")
                if qid in self._quest_map:
                    self._quest_map[qid]["seconds_done"] = seconds_needed
                log_quest(self._get_token_id(), name, qid, alt_task_type, "completed", "success")
                return True

        self._log(f"⚠️ Video failed: {name} ({seconds_done:.0f}/{seconds_needed}s)", "warn")
        log_quest(self._get_token_id(), name, qid, task_type or "WATCH_VIDEO", "failed", "failed")
        return False

    def _complete_heartbeat(self, quest: dict) -> bool:
        """Complete PLAY_ON_DESKTOP / STREAM_ON_DESKTOP using heartbeat."""
        name = get_quest_name(quest)
        qid = quest["id"]
        task_type = get_task_type(quest)
        seconds_needed = get_seconds_needed(quest)
        seconds_done = get_seconds_done(quest)
        pid = random.randint(1000, 30000)

        if qid in self._quest_map:
            self._quest_map[qid].update(seconds_needed=seconds_needed, seconds_done=seconds_done)

        self._log(f"{task_type}: {name} ({seconds_done:.0f}/{seconds_needed}s)", "progress")

        while seconds_done < seconds_needed and not self._stop.is_set():
            try:
                r = self._api.post(f"/quests/{qid}/heartbeat", {
                    "stream_key": f"call:0:{pid}",
                    "terminal": False,
                })
                if r.status_code == 200:
                    body = r.json()
                    prog = body.get("progress", {})
                    if task_type in prog:
                        val = prog[task_type]
                        seconds_done = float(val.get("value", seconds_done) if isinstance(val, dict) else val)
                    # FIX: Nếu Discord xác nhận completed_at → set 100% để hiển thị đúng
                    discord_completed = bool(body.get("completed_at"))
                    if discord_completed:
                        seconds_done = seconds_needed  # Hiển thị 100%
                    if qid in self._quest_map:
                        self._quest_map[qid]["seconds_done"] = seconds_done
                    self._log(f"  {name}: {seconds_done:.0f}/{seconds_needed}s", "progress")
                    if discord_completed or seconds_done >= seconds_needed:
                        break
                elif r.status_code == 429:
                    wait = r.json().get("retry_after", 1)
                    time.sleep(wait)
                    continue
                elif r.status_code in (400, 404):
                    self._log(f"Invalid quest ({r.status_code}), skipping", "warn")
                    break
            except Exception as e:
                self._log(f"Heartbeat error: {e}", "error")
            time.sleep(HEARTBEAT_INTERVAL)

        try:
            self._api.post(f"/quests/{qid}/heartbeat", {"stream_key": f"call:0:{pid}", "terminal": True})
        except Exception:
            pass

        ok = seconds_done >= seconds_needed
        self._log(f"{'✅' if ok else '⚠️'} Heartbeat {'completed' if ok else 'not completed'}: {name}", "ok" if ok else "warn")
        log_quest(self._get_token_id(), name, qid, task_type or "", "completed" if ok else "failed", "success" if ok else "failed")
        return ok

    def _complete_activity(self, quest: dict) -> bool:
        """Complete PLAY_ACTIVITY using heartbeat."""
        name = get_quest_name(quest)
        qid = quest["id"]
        seconds_needed = get_seconds_needed(quest)
        seconds_done = get_seconds_done(quest)

        if qid in self._quest_map:
            self._quest_map[qid].update(seconds_needed=seconds_needed, seconds_done=seconds_done)

        self._log(f"PLAY_ACTIVITY: {name} ({seconds_done:.0f}/{seconds_needed}s)", "progress")
        stream_key = "call:0:1"

        while seconds_done < seconds_needed and not self._stop.is_set():
            try:
                r = self._api.post(f"/quests/{qid}/heartbeat", {"stream_key": stream_key, "terminal": False})
                if r.status_code == 200:
                    body = r.json()
                    prog = body.get("progress", {})
                    if "PLAY_ACTIVITY" in prog:
                        val = prog["PLAY_ACTIVITY"]
                        seconds_done = float(val.get("value", seconds_done) if isinstance(val, dict) else val)
                    # FIX: Nếu Discord xác nhận completed_at → set 100%
                    discord_completed = bool(body.get("completed_at"))
                    if discord_completed:
                        seconds_done = seconds_needed  # Hiển thị 100%
                    if qid in self._quest_map:
                        self._quest_map[qid]["seconds_done"] = seconds_done
                    self._log(f"  {name}: {seconds_done:.0f}/{seconds_needed}s", "progress")
                    if discord_completed or seconds_done >= seconds_needed:
                        break
                elif r.status_code == 429:
                    wait = r.json().get("retry_after", 1)
                    time.sleep(wait)
                    continue
                elif r.status_code in (400, 404):
                    break
            except Exception as e:
                self._log(f"Activity error: {e}", "error")
            time.sleep(HEARTBEAT_INTERVAL)

        try:
            self._api.post(f"/quests/{qid}/heartbeat", {"stream_key": stream_key, "terminal": True})
        except Exception:
            pass

        ok = seconds_done >= seconds_needed
        self._log(f"{'✅' if ok else '⚠️'} Activity {'completed' if ok else 'not completed'}: {name}", "ok" if ok else "warn")
        log_quest(self._get_token_id(), name, qid, "PLAY_ACTIVITY", "completed" if ok else "failed", "success" if ok else "failed")
        return ok

    def _process_quest(self, quest: dict) -> bool:
        qid = quest.get("id")
        name = get_quest_name(quest)
        task_type = get_task_type(quest)

        if not task_type:
            self._log(f'"{name}" – unsupported task, skipping', "warn")
            return False
        if qid in self._completed_ids:
            return True

        self._log(f"━━━ {name} (task: {task_type}) ━━━", "info")

        if task_type in VIDEO_TASKS:
            return self._complete_video(quest)
        if task_type in ("PLAY_ON_DESKTOP", "STREAM_ON_DESKTOP"):
            return self._complete_heartbeat(quest)
        if task_type == "PLAY_ACTIVITY":
            return self._complete_activity(quest)
        return False

    # ── Main loop ─────────────────────────────────────────────────────────────

    def run(self):
        self._running = True
        self._last_status = "running"
        self._log("Worker started", "info")

        self._fetch_build()
        update_account_status(self.user_id, "running")
        self._session_id = start_session(self._get_token_id())
        self._log(f"Session #{self._session_id} started", "ok")

        cycle = 0
        while not self._stop.is_set():
            cycle += 1
            self._status_msg = f"Scan #{cycle}"
            self._log(f"── Scan #{cycle} ──", "info")

            quests = self._fetch_quests()

            if quests:
                enrolled_c   = sum(1 for q in quests if is_enrolled(q))
                completed_c  = sum(1 for q in quests if is_completed(q))
                completable_c = sum(1 for q in quests if is_completable(q))
                self._log(
                    f"Total: {len(quests)} | Enrolled: {enrolled_c} | "
                    f"Completed: {completed_c} | Completable: {completable_c}", "info"
                )

                for q in quests:
                    if not is_completable(q) and not is_completed(q):
                        self._debug_quest(q)

                # Cập nhật quest_map
                for q in quests:
                    if is_completable(q):
                        qid = q.get("id")
                        if qid not in self._quest_map:
                            self._quest_map[qid] = {
                                "name": get_quest_name(q),
                                "status": "waiting",
                                "seconds_done": get_seconds_done(q),
                                "seconds_needed": get_seconds_needed(q),
                                "task_type": get_task_type(q) or "",
                            }
                        if is_completed(q) or qid in self._completed_ids:
                            self._quest_map[qid]["status"] = "done"

                # Auto-enroll
                if self.auto_accept:
                    unaccepted = [
                        q for q in quests
                        if not is_enrolled(q) and not is_completed(q) and is_completable(q)
                    ]
                    if unaccepted:
                        self._log(f"Auto-enrolling {len(unaccepted)} quest...", "info")
                        for idx, q in enumerate(unaccepted):
                            qid_enroll = q.get("id")
                            tt = get_task_type(q)
                            self._log(f"  → {get_quest_name(q)} [{tt}]", "info")
                            # Đổi status "enrolling" để GUI hiện "đang nhận"
                            if qid_enroll in self._quest_map:
                                self._quest_map[qid_enroll]["status"] = "enrolling"
                            self._send_channel_update()
                            self._enroll_quest(q)
                            # Sau enroll → đổi thành "waiting"
                            if qid_enroll in self._quest_map:
                                self._quest_map[qid_enroll]["status"] = "waiting"
                            if idx < len(unaccepted) - 1:
                                time.sleep(random.uniform(QUEST_ENROLL_DELAY_MIN, QUEST_ENROLL_DELAY_MAX))
                        quests = self._fetch_quests()
                        for q in quests:
                            if is_completable(q):
                                qid = q.get("id")
                                if qid not in self._quest_map:
                                    self._quest_map[qid] = {
                                        "name": get_quest_name(q),
                                        "status": "waiting",
                                        "seconds_done": get_seconds_done(q),
                                        "seconds_needed": get_seconds_needed(q),
                                        "task_type": get_task_type(q) or "",
                                    }
                                if is_completed(q) or qid in self._completed_ids:
                                    self._quest_map[qid]["status"] = "done"

                # Ping lần đầu — luôn gửi sau cycle đầu tiên dù có quest hay không
                if not self._notified_start:
                    self._send_start_ping()
                    self._notified_start = True
                    self._start_live_updater()

                # FIX: Lấy quest cần làm, ưu tiên VIDEO trước
                actionable_raw = [
                    q for q in quests
                    if is_enrolled(q) and not is_completed(q) and is_completable(q)
                    and q.get("id") not in self._completed_ids
                ]
                # Ưu tiên WATCH_VIDEO / WATCH_VIDEO_ON_MOBILE trước
                video_quests = [q for q in actionable_raw if get_task_type(q) in VIDEO_TASKS]
                other_quests = [q for q in actionable_raw if get_task_type(q) not in VIDEO_TASKS]
                actionable = video_quests + other_quests

                if actionable:
                    self._log(
                        f"{len(actionable)} actionable quest(s) "
                        f"(video={len(video_quests)}, game={len(other_quests)}) — video first, game second",
                        "info"
                    )
                    for q in actionable:
                        qid = q.get("id")
                        if qid in self._quest_map:
                            self._quest_map[qid]["status"] = "running"
                    self._send_both_update()

                    def _run_one(q, stagger: float = 0):
                        if stagger:
                            time.sleep(stagger)
                        if self._stop.is_set():
                            return
                        qid = q.get("id")
                        name = get_quest_name(q)
                        ok = self._process_quest(q)
                        if ok:
                            with self._lock:
                                self._completed_ids.add(qid)
                            self._retry_counts.pop(name, None)
                            if qid in self._quest_map:
                                self._quest_map[qid]["status"] = "done"
                        else:
                            self._retry_counts[name] = self._retry_counts.get(name, 0) + 1
                            if qid in self._quest_map:
                                self._quest_map[qid]["status"] = "failed"
                        self._send_both_update()

                    # ── PHASE 1: Video quests TRƯỚC — tối đa 3 thread cùng lúc ────
                    if video_quests and not self._stop.is_set():
                        self._log(f"▶ PHASE 1: {len(video_quests)} video quest (max {QUEST_MAX_WORKERS} thread)", "info")
                        with concurrent.futures.ThreadPoolExecutor(
                            max_workers=min(len(video_quests), QUEST_MAX_WORKERS),
                            thread_name_prefix="video"
                        ) as pool:
                            futs = [pool.submit(_run_one, q, QUEST_ACTION_DELAY * i) for i, q in enumerate(video_quests)]
                            concurrent.futures.wait(futs)
                        gc.collect()
                        self._log("✅ PHASE 1 completed", "ok")

                    # ── PHASE 2: Game quests SAU — tối đa 3 thread cùng lúc ──────
                    if other_quests and not self._stop.is_set():
                        with self._lock:
                            done_ids = set(self._completed_ids)
                        remaining = [q for q in other_quests if q.get("id") not in done_ids]
                        if remaining:
                            self._log(f"▶ PHASE 2: {len(remaining)} game quest (max {QUEST_MAX_WORKERS} thread)", "info")
                            with concurrent.futures.ThreadPoolExecutor(
                                max_workers=min(len(remaining), QUEST_MAX_WORKERS),
                                thread_name_prefix="game"
                            ) as pool:
                                futs = [
                                    pool.submit(_run_one, q, QUEST_ACTION_DELAY * i)
                                    for i, q in enumerate(remaining)
                                ]
                                concurrent.futures.wait(futs)
                            gc.collect()

                else:
                    self._log("No actionable quests", "info")

                # Kiểm tra tất cả đã completed chưa
                if self._quest_map and not self._completion_sent and not self._stop.is_set():
                    has_pending = any(v["status"] in ("running", "waiting") for v in self._quest_map.values())
                    all_local_done = (not has_pending and
                                      all(v["status"] in ("done", "failed") for v in self._quest_map.values()) and
                                      any(v["status"] == "done" for v in self._quest_map.values()))
                    if all_local_done:
                        # Retry tối đa 3 lần nếu API trả về rỗng
                        final_quests = []
                        for _retry in range(3):
                            final_quests = self._fetch_quests()
                            if final_quests:
                                break
                            if _retry < 2:
                                time.sleep(2)

                        if not final_quests:
                            # Không lấy được dữ liệu → KHÔNG gửi hoàn thành, chờ vòng sau
                            self._log("⚠️ Could not verify the quest list from Discord — skipping and retrying later", "warn")
                            discord_all_done = False
                        else:
                            discord_all_done = all(
                                is_completed(q) or not is_completable(q)
                                for q in final_quests
                            )

                        # Nếu Discord vẫn chưa xác nhận quest hoàn thành, reset về waiting để thử lại
                        if not discord_all_done and final_quests:
                            for q in final_quests:
                                qid_chk = q.get("id")
                                if (qid_chk in self._quest_map
                                        and is_completable(q)
                                        and not is_completed(q)):
                                    self._quest_map[qid_chk]["status"] = "waiting"
                                    with self._lock:
                                        self._completed_ids.discard(qid_chk)
                                    sd_pct = get_seconds_done(q)
                                    sn_pct = get_seconds_needed(q)
                                    pct = f"{sd_pct/sn_pct*100:.0f}%" if sn_pct else "?"
                                    self._log(
                                        f"⚠️ {get_quest_name(q)}: Discord is still at {pct} "
                                        f"({sd_pct:.0f}/{sn_pct:.0f}s) — resetting to waiting and retrying",
                                        "warn",
                                    )

                        if discord_all_done:
                            self._log("✅ All quests completed! Stopping worker...", "ok")
                            bot_done = sum(1 for v in self._quest_map.values() if v["status"] == "done")
                            expired_c = sum(1 for q in final_quests if is_expired_quest(q))
                            disc_done = sum(1 for q in final_quests if is_completed(q))
                            actual = max(bot_done, disc_done)
                            self._final_stats = {"completed": actual, "expired": expired_c, "total": actual + expired_c}
                            self._send_both_update(completed_all=True)
                            self._send_completion_to_channel()
                            self._completion_sent = True
                            from database import set_manually_stopped as _sms
                            _sms(self.user_id, True)
                            self._stop.set()

                    # FIX: Nếu chỉ có quest failed (chưa done nào), không bail — thử lại sau
                    elif (not has_pending and
                          all(v["status"] == "failed" for v in self._quest_map.values())):
                        total_retries = sum(self._retry_counts.values())
                        if total_retries >= 5:
                            self._log("⚠️ All quests failed after multiple attempts; stopping worker", "warn")
                            self._stop.set()
                        else:
                            # Reset failed → waiting để thử lại
                            self._log(f"⚠️ Quest failed; retrying in {self.poll_interval}s...", "warn")
                            for v in self._quest_map.values():
                                if v["status"] == "failed":
                                    v["status"] = "waiting"

            else:
                self._log("No quests", "info")
                # Cập nhật pre-channel msg nếu chưa gửi thông báo bắt đầu
                if not self._notified_start:
                    self._send_channel_update()
                    self._notified_start = True
                    self._start_live_updater()

            for _ in range(self.poll_interval):
                if self._stop.is_set():
                    break
                time.sleep(1)

        # Cleanup — giải phóng RAM
        self._running = False
        self._live_updater_active = False
        self._last_status = "stopped"
        reason = "completed" if self._completion_sent else "manual"
        self._status_msg = "Completed" if self._completion_sent else "Stopped"
        if self._session_id:
            stop_session(self._session_id, reason)
        update_account_status(self.user_id, "offline")
        with _worker_lock:
            _active_workers.pop(self.user_id, None)
        # Đóng HTTP session và giải phóng bộ nhớ
        try:
            self._api.close()
        except Exception:
            pass
        self._quest_map.clear()
        self._completed_ids.clear()
        self._retry_counts.clear()
        gc.collect()
        self._log(f"Worker stopped ({reason})", "info")

    def _get_token_id(self) -> int:
        from database import get_all_accounts
        for acc in get_all_accounts():
            if acc.get("user_id") == self.user_id:
                return acc.get("id", 1)
        return 1

    def stop(self):
        self._stop.set()
        self._live_updater_active = False


# ── Global registry ────────────────────────────────────────────────────────────

_worker_lock = threading.Lock()
_active_workers: dict = {}


def start_worker(token: str, user_id: str, username: str,
                 poll_interval: int = 60, auto_accept: bool = True,
                 bot_client=None, channel_id: int = None,
                 requester_discord_id: str = None, avatar_url: str = None,
                 silent: bool = False, on_complete_callback=None,
                 pre_channel_msg=None) -> QuestWorker:
    stop_worker(user_id)
    ev = threading.Event()
    w = QuestWorker(token, user_id, username, poll_interval, auto_accept, ev,
                    bot_client, channel_id, requester_discord_id, avatar_url,
                    silent=silent, on_complete_callback=on_complete_callback,
                    pre_channel_msg=pre_channel_msg)
    with _worker_lock:
        _active_workers[user_id] = w
    w.start()
    return w


def stop_worker(user_id: str):
    with _worker_lock:
        if user_id in _active_workers:
            _active_workers[user_id].stop()
            del _active_workers[user_id]


def get_worker(user_id: str) -> Optional[QuestWorker]:
    return _active_workers.get(user_id)


def get_all_workers() -> dict:
    return dict(_active_workers)


